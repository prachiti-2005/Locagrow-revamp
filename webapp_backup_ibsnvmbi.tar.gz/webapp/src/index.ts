import { Hono } from 'hono';
import { landingPage, loginPage, signupPage } from './pages/landing';
import { farmerDashboard } from './pages/farmer/dashboard';
import { farmerCrops } from './pages/farmer/crops';
import { farmerSoilTest } from './pages/farmer/soil-test';
import { farmerLabFinder } from './pages/farmer/lab-finder';
import { farmerPesticide } from './pages/farmer/pesticide';
import { farmerTraders, farmerOrders, farmerDelivery } from './pages/farmer/extras';
import { traderDashboard } from './pages/trader/dashboard';
import { traderFarmers, traderMarketplace, traderProducts, traderOrders, traderDelivery, traderAnalytics } from './pages/trader/extras';
import { buyerDashboard } from './pages/buyer/dashboard';
import { buyerBrowse, buyerCart, buyerCheckout, buyerOrders, buyerTracking } from './pages/buyer/extras';

const app = new Hono();

// Landing & Auth
app.get('/', (c) => c.html(landingPage()));
app.get('/login', (c) => c.html(loginPage()));
app.get('/signup', (c) => c.html(signupPage()));

// Farmer routes
app.get('/farmer/dashboard', (c) => c.html(farmerDashboard()));
app.get('/farmer/crops', (c) => c.html(farmerCrops()));
app.get('/farmer/soil-test', (c) => c.html(farmerSoilTest()));
app.get('/farmer/lab-finder', (c) => c.html(farmerLabFinder()));
app.get('/farmer/pesticide', (c) => c.html(farmerPesticide()));
app.get('/farmer/traders', (c) => c.html(farmerTraders()));
app.get('/farmer/orders', (c) => c.html(farmerOrders()));
app.get('/farmer/delivery', (c) => c.html(farmerDelivery()));

// Trader routes
app.get('/trader/dashboard', (c) => c.html(traderDashboard()));
app.get('/trader/farmers', (c) => c.html(traderFarmers()));
app.get('/trader/marketplace', (c) => c.html(traderMarketplace()));
app.get('/trader/products', (c) => c.html(traderProducts()));
app.get('/trader/orders', (c) => c.html(traderOrders()));
app.get('/trader/delivery', (c) => c.html(traderDelivery()));
app.get('/trader/analytics', (c) => c.html(traderAnalytics()));

// Buyer routes
app.get('/buyer/dashboard', (c) => c.html(buyerDashboard()));
app.get('/buyer/browse', (c) => c.html(buyerBrowse()));
app.get('/buyer/cart', (c) => c.html(buyerCart()));
app.get('/buyer/checkout', (c) => c.html(buyerCheckout()));
app.get('/buyer/orders', (c) => c.html(buyerOrders()));
app.get('/buyer/tracking', (c) => c.html(buyerTracking()));

// API routes for mock data
app.get('/api/health', (c) => c.json({ status: 'ok', timestamp: new Date().toISOString() }));

app.get('/api/products', (c) => {
  return c.json({
    products: [
      { id: 1, name: 'Organic Wheat', price: 35, unit: 'kg', seller: 'Ramesh Farm', category: 'Grains' },
      { id: 2, name: 'Basmati Rice', price: 80, unit: 'kg', seller: 'Krishna Wholesale', category: 'Grains' },
      { id: 3, name: 'Fresh Tomatoes', price: 40, unit: 'kg', seller: 'Sunil Farms', category: 'Vegetables' },
      { id: 4, name: 'Red Onions', price: 30, unit: 'kg', seller: 'Sahyadri Traders', category: 'Vegetables' },
      { id: 5, name: 'Green Chillies', price: 60, unit: 'kg', seller: 'Priya Farm', category: 'Vegetables' },
      { id: 6, name: 'Potatoes', price: 25, unit: 'kg', seller: 'Metro Agri', category: 'Vegetables' },
    ]
  });
});

app.get('/api/market-prices', (c) => {
  return c.json({
    prices: [
      { crop: 'Wheat', price: 25, change: '+2.5%', trend: 'up' },
      { crop: 'Rice', price: 35, change: '+1.2%', trend: 'up' },
      { crop: 'Tomatoes', price: 40, change: '-5.0%', trend: 'down' },
      { crop: 'Onions', price: 30, change: '+8.3%', trend: 'up' },
      { crop: 'Potatoes', price: 20, change: '-1.5%', trend: 'down' },
    ]
  });
});

export default app;
