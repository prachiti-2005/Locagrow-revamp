export function baseLayout(title: string, body: string, activeRole?: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} - AgriMarket</title>
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: { 50:'#f0fdf4',100:'#dcfce7',200:'#bbf7d0',300:'#86efac',400:'#4ade80',500:'#22c55e',600:'#16a34a',700:'#15803d',800:'#166534',900:'#14532d' },
            earth: { 50:'#faf8f5',100:'#f5f0e8',200:'#e8dcc8',300:'#d4c4a0',400:'#bfa878',500:'#a08c5a',600:'#857347',700:'#6b5b38',800:'#554a2f',900:'#463e28' }
          }
        }
      }
    }
  </script>
  <style>
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slideIn { from { transform: translateX(-100%); } to { transform: translateX(0); } }
    @keyframes pulse-soft { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
    .animate-fade-in { animation: fadeIn 0.5s ease-out forwards; }
    .animate-slide-in { animation: slideIn 0.3s ease-out forwards; }
    .card-hover { transition: all 0.3s ease; }
    .card-hover:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.08); }
    .btn-primary { background: linear-gradient(135deg, #22c55e, #16a34a); transition: all 0.3s ease; }
    .btn-primary:hover { background: linear-gradient(135deg, #16a34a, #15803d); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(34,197,94,0.4); }
    .sidebar-link { transition: all 0.2s ease; }
    .sidebar-link:hover, .sidebar-link.active { background: rgba(34,197,94,0.1); color: #16a34a; border-right: 3px solid #16a34a; }
    .glass { background: rgba(255,255,255,0.8); backdrop-filter: blur(12px); }
    .gradient-bg { background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #f0fdf4 100%); }
    body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    .mobile-menu { display: none; }
    .mobile-menu.open { display: block; }
    @media (max-width: 768px) {
      .sidebar-desktop { display: none; }
      .main-content { margin-left: 0 !important; }
    }
  </style>
</head>
<body class="bg-gray-50 min-h-screen">
  ${body}
  <script src="/static/app.js"></script>
</body>
</html>`;
}

export function dashboardLayout(title: string, role: string, body: string, activePage: string): string {
  const roleLabels: Record<string, string> = { farmer: 'Farmer', trader: 'Trader', buyer: 'Buyer' };
  const roleIcons: Record<string, string> = { farmer: 'fa-seedling', trader: 'fa-handshake', buyer: 'fa-shopping-bag' };
  const roleColors: Record<string, string> = { farmer: 'primary', trader: 'amber', buyer: 'blue' };

  const navItems: Record<string, Array<{href:string; icon:string; label:string; id:string}>> = {
    farmer: [
      { href: '/farmer/dashboard', icon: 'fa-tachometer-alt', label: 'Dashboard', id: 'dashboard' },
      { href: '/farmer/crops', icon: 'fa-leaf', label: 'My Crops', id: 'crops' },
      { href: '/farmer/soil-test', icon: 'fa-flask', label: 'Soil Testing', id: 'soil-test' },
      { href: '/farmer/lab-finder', icon: 'fa-map-marker-alt', label: 'Lab Finder', id: 'lab-finder' },
      { href: '/farmer/pesticide', icon: 'fa-bug', label: 'AI Suggestions', id: 'pesticide' },
      { href: '/farmer/traders', icon: 'fa-users', label: 'Find Traders', id: 'traders' },
      { href: '/farmer/orders', icon: 'fa-clipboard-list', label: 'Orders', id: 'orders' },
      { href: '/farmer/delivery', icon: 'fa-truck', label: 'Delivery', id: 'delivery' },
    ],
    trader: [
      { href: '/trader/dashboard', icon: 'fa-tachometer-alt', label: 'Dashboard', id: 'dashboard' },
      { href: '/trader/farmers', icon: 'fa-users', label: 'Nearby Farmers', id: 'farmers' },
      { href: '/trader/marketplace', icon: 'fa-store', label: 'Marketplace', id: 'marketplace' },
      { href: '/trader/products', icon: 'fa-boxes', label: 'My Products', id: 'products' },
      { href: '/trader/orders', icon: 'fa-clipboard-list', label: 'Orders', id: 'orders' },
      { href: '/trader/delivery', icon: 'fa-truck', label: 'Delivery', id: 'delivery' },
      { href: '/trader/analytics', icon: 'fa-chart-line', label: 'Analytics', id: 'analytics' },
    ],
    buyer: [
      { href: '/buyer/dashboard', icon: 'fa-tachometer-alt', label: 'Dashboard', id: 'dashboard' },
      { href: '/buyer/browse', icon: 'fa-search', label: 'Browse Products', id: 'browse' },
      { href: '/buyer/cart', icon: 'fa-shopping-cart', label: 'My Cart', id: 'cart' },
      { href: '/buyer/orders', icon: 'fa-clipboard-list', label: 'Orders', id: 'orders' },
      { href: '/buyer/tracking', icon: 'fa-map-marked', label: 'Track Order', id: 'tracking' },
    ]
  };

  const items = navItems[role] || [];
  const sidebarLinks = items.map(item => 
    `<a href="${item.href}" class="sidebar-link flex items-center gap-3 px-4 py-3 rounded-lg text-gray-600 ${activePage === item.id ? 'active bg-primary-50 text-primary-700 font-medium' : ''}">
      <i class="fas ${item.icon} w-5 text-center"></i>
      <span>${item.label}</span>
    </a>`
  ).join('');

  const mobileLinks = items.map(item =>
    `<a href="${item.href}" class="block px-4 py-3 text-gray-600 hover:bg-primary-50 hover:text-primary-700 ${activePage === item.id ? 'bg-primary-50 text-primary-700 font-medium' : ''}">${item.label}</a>`
  ).join('');

  const content = `
  <!-- Mobile Header -->
  <header class="md:hidden fixed top-0 left-0 right-0 z-50 glass border-b border-gray-200">
    <div class="flex items-center justify-between px-4 py-3">
      <div class="flex items-center gap-2">
        <i class="fas fa-leaf text-primary-600 text-xl"></i>
        <span class="font-bold text-gray-800">AgriMarket</span>
      </div>
      <div class="flex items-center gap-3">
        <span class="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">${roleLabels[role]}</span>
        <button onclick="toggleMobileMenu()" class="text-gray-600 text-xl"><i class="fas fa-bars"></i></button>
      </div>
    </div>
    <div id="mobileMenu" class="mobile-menu border-t border-gray-100">
      ${mobileLinks}
      <a href="/" class="block px-4 py-3 text-red-500 hover:bg-red-50 border-t border-gray-100">
        <i class="fas fa-sign-out-alt mr-2"></i>Logout
      </a>
    </div>
  </header>

  <!-- Sidebar Desktop -->
  <aside class="sidebar-desktop fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-gray-200 z-40 flex flex-col">
    <div class="p-6 border-b border-gray-100">
      <a href="/" class="flex items-center gap-2">
        <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
          <i class="fas fa-leaf text-primary-600 text-lg"></i>
        </div>
        <div>
          <h1 class="font-bold text-gray-800 text-lg">AgriMarket</h1>
          <p class="text-xs text-gray-400">Agricultural Hub</p>
        </div>
      </a>
    </div>
    <div class="p-4 mx-4 mt-4 bg-primary-50 rounded-xl">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 bg-primary-200 rounded-full flex items-center justify-center">
          <i class="fas ${roleIcons[role]} text-primary-700"></i>
        </div>
        <div>
          <p class="font-medium text-gray-800 text-sm">Demo User</p>
          <p class="text-xs text-primary-600">${roleLabels[role]} Account</p>
        </div>
      </div>
    </div>
    <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
      ${sidebarLinks}
    </nav>
    <div class="p-4 border-t border-gray-100">
      <a href="/" class="sidebar-link flex items-center gap-3 px-4 py-3 rounded-lg text-red-500">
        <i class="fas fa-sign-out-alt w-5 text-center"></i>
        <span>Logout</span>
      </a>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="main-content md:ml-64 min-h-screen">
    <div class="pt-16 md:pt-0">
      <!-- Top Bar -->
      <div class="hidden md:flex items-center justify-between px-8 py-4 bg-white border-b border-gray-100">
        <div>
          <h2 class="text-xl font-bold text-gray-800">${title}</h2>
          <p class="text-sm text-gray-400">Welcome back, Demo User</p>
        </div>
        <div class="flex items-center gap-4">
          <button class="relative p-2 text-gray-400 hover:text-gray-600">
            <i class="fas fa-bell text-lg"></i>
            <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <div class="w-9 h-9 bg-primary-200 rounded-full flex items-center justify-center">
            <i class="fas fa-user text-primary-700 text-sm"></i>
          </div>
        </div>
      </div>
      <!-- Page Content -->
      <div class="p-4 md:p-8">
        ${body}
      </div>
    </div>
  </main>`;

  return baseLayout(title, content, role);
}
