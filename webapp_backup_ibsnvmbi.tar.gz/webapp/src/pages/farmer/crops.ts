import { dashboardLayout } from '../../layout';

export function farmerCrops(): string {
  const crops = [
    { id: 1, name: 'Organic Wheat', category: 'Grains', price: 25, unit: 'kg', qty: 5000, status: 'active', img: 'fa-wheat-awn' },
    { id: 2, name: 'Basmati Rice', category: 'Grains', price: 65, unit: 'kg', qty: 3000, status: 'active', img: 'fa-seedling' },
    { id: 3, name: 'Fresh Tomatoes', category: 'Vegetables', price: 40, unit: 'kg', qty: 800, status: 'active', img: 'fa-apple-whole' },
    { id: 4, name: 'Red Onions', category: 'Vegetables', price: 30, unit: 'kg', qty: 1200, status: 'low', img: 'fa-carrot' },
    { id: 5, name: 'Green Chillies', category: 'Vegetables', price: 60, unit: 'kg', qty: 200, status: 'active', img: 'fa-pepper-hot' },
    { id: 6, name: 'Potatoes', category: 'Vegetables', price: 20, unit: 'kg', qty: 2000, status: 'active', img: 'fa-seedling' },
  ];

  const cropCards = crops.map(c => `
    <div class="bg-white rounded-2xl border border-gray-100 card-hover overflow-hidden">
      <div class="h-32 bg-gradient-to-br from-primary-50 to-primary-100 flex items-center justify-center">
        <i class="fas ${c.img} text-primary-400 text-4xl"></i>
      </div>
      <div class="p-4">
        <div class="flex items-center justify-between mb-2">
          <h4 class="font-bold text-gray-800">${c.name}</h4>
          <span class="text-xs px-2 py-1 rounded-full font-medium ${c.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}">${c.status === 'active' ? 'Active' : 'Low Stock'}</span>
        </div>
        <p class="text-xs text-gray-400 mb-3">${c.category}</p>
        <div class="flex items-center justify-between text-sm">
          <span class="font-bold text-primary-600">&#8377;${c.price}/${c.unit}</span>
          <span class="text-gray-500">${c.qty.toLocaleString()} ${c.unit}</span>
        </div>
        <div class="flex gap-2 mt-4">
          <button onclick="editCrop(${c.id})" class="flex-1 text-xs bg-gray-50 hover:bg-gray-100 text-gray-700 py-2 rounded-lg font-medium transition">
            <i class="fas fa-edit mr-1"></i>Edit
          </button>
          <button onclick="deleteCrop(${c.id})" class="text-xs bg-red-50 hover:bg-red-100 text-red-600 py-2 px-3 rounded-lg font-medium transition">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');

  const body = `
  <div class="space-y-6 animate-fade-in">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h3 class="text-lg font-bold text-gray-800">My Crop Listings</h3>
        <p class="text-sm text-gray-400">Manage your produce inventory</p>
      </div>
      <button onclick="document.getElementById('addCropModal').classList.remove('hidden')" class="btn-primary text-white px-5 py-2.5 rounded-xl text-sm font-medium inline-flex items-center gap-2">
        <i class="fas fa-plus"></i> Add New Crop
      </button>
    </div>

    <!-- Filters -->
    <div class="flex flex-wrap gap-3">
      <div class="relative flex-1 min-w-[200px]">
        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
        <input type="text" placeholder="Search crops..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
      </div>
      <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
        <option>All Categories</option>
        <option>Grains</option>
        <option>Vegetables</option>
        <option>Fruits</option>
      </select>
      <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
        <option>All Status</option>
        <option>Active</option>
        <option>Low Stock</option>
        <option>Out of Stock</option>
      </select>
    </div>

    <!-- Crop Grid -->
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      ${cropCards}
    </div>

    <!-- Add Crop Modal -->
    <div id="addCropModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-bold text-gray-800">Add New Crop</h3>
          <button onclick="document.getElementById('addCropModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <form onsubmit="handleAddCrop(event)" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Crop Name</label>
            <input type="text" placeholder="e.g., Organic Wheat" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500" required>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none" required>
                <option value="">Select</option>
                <option>Grains</option>
                <option>Vegetables</option>
                <option>Fruits</option>
                <option>Pulses</option>
                <option>Spices</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Unit</label>
              <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none">
                <option>kg</option>
                <option>quintal</option>
                <option>ton</option>
                <option>pieces</option>
              </select>
            </div>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Price per unit (&#8377;)</label>
              <input type="number" placeholder="0.00" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500" required>
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Available Quantity</label>
              <input type="number" placeholder="0" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500" required>
            </div>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea rows="3" placeholder="Describe your crop quality, farming method etc." class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500 resize-none"></textarea>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Upload Images</label>
            <div class="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center cursor-pointer hover:border-primary-300 transition">
              <i class="fas fa-cloud-upload-alt text-gray-300 text-3xl mb-2"></i>
              <p class="text-sm text-gray-400">Click to upload or drag and drop</p>
              <p class="text-xs text-gray-300 mt-1">PNG, JPG up to 5MB</p>
              <input type="file" class="hidden" accept="image/*" multiple>
            </div>
          </div>
          <div class="flex gap-3 pt-2">
            <button type="button" onclick="document.getElementById('addCropModal').classList.add('hidden')" class="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition">Cancel</button>
            <button type="submit" class="flex-1 btn-primary text-white py-2.5 rounded-xl text-sm font-medium">Add Crop</button>
          </div>
        </form>
      </div>
    </div>
  </div>`;

  return dashboardLayout('My Crops', 'farmer', body, 'crops');
}
