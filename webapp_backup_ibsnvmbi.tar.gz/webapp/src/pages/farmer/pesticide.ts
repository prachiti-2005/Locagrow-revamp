import { dashboardLayout } from '../../layout';

export function farmerPesticide(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid lg:grid-cols-3 gap-6">
      <!-- Input Panel -->
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-1">AI Crop Advisor</h3>
        <p class="text-sm text-gray-400 mb-5">Get smart pesticide & fertilizer recommendations</p>
        
        <form onsubmit="runAIAdvice(event)" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Crop</label>
            <select id="aiCrop" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500">
              <option value="wheat">Wheat</option>
              <option value="rice">Rice</option>
              <option value="cotton">Cotton</option>
              <option value="tomato">Tomato</option>
              <option value="onion">Onion</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Growth Stage</label>
            <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none">
              <option>Seedling</option><option>Vegetative</option><option>Flowering</option><option>Fruiting</option><option>Harvesting</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Observed Issues</label>
            <div class="space-y-2">
              <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="rounded text-primary-500" checked> Yellow leaves</label>
              <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="rounded text-primary-500"> Pest infestation</label>
              <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="rounded text-primary-500"> Fungal growth</label>
              <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="rounded text-primary-500"> Stunted growth</label>
              <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="rounded text-primary-500"> Wilting</label>
            </div>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Upload Crop Photo (optional)</label>
            <div class="border-2 border-dashed border-gray-200 rounded-xl p-4 text-center cursor-pointer hover:border-primary-300 transition">
              <i class="fas fa-camera text-gray-300 text-xl mb-1"></i>
              <p class="text-xs text-gray-400">Click to upload</p>
            </div>
          </div>
          <button type="submit" class="btn-primary w-full text-white py-3 rounded-xl text-sm font-medium"><i class="fas fa-brain mr-2"></i>Get AI Recommendations</button>
        </form>
      </div>

      <!-- Results Panel -->
      <div class="lg:col-span-2 space-y-6">
        <div id="aiPlaceholder" class="bg-white rounded-2xl p-12 border border-gray-100 text-center">
          <div class="w-20 h-20 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-brain text-purple-300 text-3xl"></i>
          </div>
          <p class="text-gray-400 mb-1">No analysis yet</p>
          <p class="text-sm text-gray-300">Fill the form and click "Get AI Recommendations"</p>
        </div>

        <div id="aiLoading" class="hidden bg-white rounded-2xl p-12 border border-gray-100 text-center">
          <div class="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p class="text-gray-500">AI is analyzing your crop data...</p>
        </div>

        <div id="aiResults" class="hidden space-y-4">
          <!-- Diagnosis -->
          <div class="bg-white rounded-2xl p-6 border border-gray-100">
            <div class="flex items-center gap-3 mb-4">
              <div class="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center"><i class="fas fa-stethoscope text-red-600"></i></div>
              <div>
                <h4 class="font-bold text-gray-800">Diagnosis</h4>
                <p class="text-xs text-gray-400">Identified issues with your crop</p>
              </div>
            </div>
            <div class="space-y-3">
              <div class="flex items-start gap-3 p-3 bg-red-50 rounded-xl">
                <i class="fas fa-exclamation-triangle text-red-500 mt-0.5"></i>
                <div>
                  <p class="text-sm font-medium text-gray-800">Nitrogen Deficiency Detected</p>
                  <p class="text-xs text-gray-500">Yellow leaves typically indicate insufficient nitrogen uptake. This is common during the vegetative stage.</p>
                </div>
              </div>
              <div class="flex items-start gap-3 p-3 bg-amber-50 rounded-xl">
                <i class="fas fa-exclamation-circle text-amber-500 mt-0.5"></i>
                <div>
                  <p class="text-sm font-medium text-gray-800">Early Signs of Rust Fungus</p>
                  <p class="text-xs text-gray-500">Monitor for orange-brown pustules on leaf surfaces. Preventive treatment recommended.</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Pesticide Suggestions -->
          <div class="bg-white rounded-2xl p-6 border border-gray-100">
            <div class="flex items-center gap-3 mb-4">
              <div class="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center"><i class="fas fa-bug text-purple-600"></i></div>
              <div>
                <h4 class="font-bold text-gray-800">Pesticide Recommendations</h4>
                <p class="text-xs text-gray-400">AI-suggested treatments</p>
              </div>
            </div>
            <div class="grid sm:grid-cols-2 gap-3">
              <div class="border border-gray-100 rounded-xl p-4">
                <div class="flex items-center gap-2 mb-2">
                  <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                  <span class="text-xs text-green-700 font-medium">Recommended</span>
                </div>
                <p class="font-medium text-gray-800 text-sm">Propiconazole 25% EC</p>
                <p class="text-xs text-gray-500 mt-1">Dosage: 1ml per liter of water</p>
                <p class="text-xs text-gray-400 mt-1">Apply at 15-day intervals, 2 sprays</p>
                <p class="text-xs font-medium text-primary-600 mt-2">&#8377;450 / liter</p>
              </div>
              <div class="border border-gray-100 rounded-xl p-4">
                <div class="flex items-center gap-2 mb-2">
                  <span class="w-2 h-2 bg-blue-500 rounded-full"></span>
                  <span class="text-xs text-blue-700 font-medium">Alternative</span>
                </div>
                <p class="font-medium text-gray-800 text-sm">Mancozeb 75% WP</p>
                <p class="text-xs text-gray-500 mt-1">Dosage: 2.5g per liter of water</p>
                <p class="text-xs text-gray-400 mt-1">Apply at 10-day intervals, 3 sprays</p>
                <p class="text-xs font-medium text-primary-600 mt-2">&#8377;280 / kg</p>
              </div>
              <div class="border border-gray-100 rounded-xl p-4">
                <div class="flex items-center gap-2 mb-2">
                  <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                  <span class="text-xs text-green-700 font-medium">Organic Option</span>
                </div>
                <p class="font-medium text-gray-800 text-sm">Neem Oil Extract</p>
                <p class="text-xs text-gray-500 mt-1">Dosage: 5ml per liter of water</p>
                <p class="text-xs text-gray-400 mt-1">Apply weekly, eco-friendly solution</p>
                <p class="text-xs font-medium text-primary-600 mt-2">&#8377;350 / liter</p>
              </div>
              <div class="border border-gray-100 rounded-xl p-4">
                <div class="flex items-center gap-2 mb-2">
                  <span class="w-2 h-2 bg-amber-500 rounded-full"></span>
                  <span class="text-xs text-amber-700 font-medium">Biological</span>
                </div>
                <p class="font-medium text-gray-800 text-sm">Trichoderma viride</p>
                <p class="text-xs text-gray-500 mt-1">Dosage: 4g per liter of water</p>
                <p class="text-xs text-gray-400 mt-1">Soil application, prevents fungal diseases</p>
                <p class="text-xs font-medium text-primary-600 mt-2">&#8377;180 / kg</p>
              </div>
            </div>
          </div>

          <!-- Fertilizer Suggestions -->
          <div class="bg-white rounded-2xl p-6 border border-gray-100">
            <div class="flex items-center gap-3 mb-4">
              <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center"><i class="fas fa-flask text-primary-600"></i></div>
              <div>
                <h4 class="font-bold text-gray-800">Fertilizer Plan</h4>
                <p class="text-xs text-gray-400">Customized nutrient schedule</p>
              </div>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="text-left text-gray-400 border-b border-gray-100">
                    <th class="pb-3 font-medium">Fertilizer</th>
                    <th class="pb-3 font-medium">Dosage</th>
                    <th class="pb-3 font-medium">When</th>
                    <th class="pb-3 font-medium">Method</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                  <tr><td class="py-3 font-medium">Urea (46% N)</td><td class="py-3">50 kg/ha</td><td class="py-3 text-gray-500">Immediately</td><td class="py-3 text-gray-500">Top dressing</td></tr>
                  <tr><td class="py-3 font-medium">DAP (18:46:0)</td><td class="py-3">25 kg/ha</td><td class="py-3 text-gray-500">Next week</td><td class="py-3 text-gray-500">Basal dose</td></tr>
                  <tr><td class="py-3 font-medium">MOP (60% K)</td><td class="py-3">20 kg/ha</td><td class="py-3 text-gray-500">After 15 days</td><td class="py-3 text-gray-500">Broadcasting</td></tr>
                  <tr><td class="py-3 font-medium">Zinc Sulphate</td><td class="py-3">5 kg/ha</td><td class="py-3 text-gray-500">With irrigation</td><td class="py-3 text-gray-500">Foliar spray</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  function runAIAdvice(e) {
    e.preventDefault();
    document.getElementById('aiPlaceholder').classList.add('hidden');
    document.getElementById('aiResults').classList.add('hidden');
    document.getElementById('aiLoading').classList.remove('hidden');
    setTimeout(function() {
      document.getElementById('aiLoading').classList.add('hidden');
      document.getElementById('aiResults').classList.remove('hidden');
    }, 2000);
  }
  </script>`;

  return dashboardLayout('AI Suggestions', 'farmer', body, 'pesticide');
}
