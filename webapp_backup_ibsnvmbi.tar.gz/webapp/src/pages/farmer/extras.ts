import { dashboardLayout } from '../../layout';

export function farmerTraders(): string {
  const traders = [
    { name: 'Rajan Agro Traders', dist: '3.2 km', rating: 4.8, deals: 156, speciality: 'Grains & Pulses', verified: true, img: 'R' },
    { name: 'Krishna Wholesale', dist: '5.8 km', rating: 4.5, deals: 98, speciality: 'Vegetables', verified: true, img: 'K' },
    { name: 'Fresh Farm Traders', dist: '7.1 km', rating: 4.3, deals: 72, speciality: 'Fruits & Vegetables', verified: false, img: 'F' },
    { name: 'Metro Agri Corp', dist: '12 km', rating: 4.9, deals: 234, speciality: 'All Crops', verified: true, img: 'M' },
    { name: 'Sahyadri Traders', dist: '15 km', rating: 4.6, deals: 145, speciality: 'Grains', verified: true, img: 'S' },
    { name: 'Deccan Agro Hub', dist: '18 km', rating: 4.1, deals: 53, speciality: 'Spices & Pulses', verified: false, img: 'D' },
  ];

  const traderCards = traders.map(t => `
    <div class="bg-white rounded-2xl border border-gray-100 p-5 card-hover">
      <div class="flex items-start gap-4">
        <div class="w-14 h-14 bg-primary-100 rounded-xl flex items-center justify-center text-primary-700 font-bold text-xl flex-shrink-0">${t.img}</div>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 mb-1">
            <h4 class="font-bold text-gray-800 truncate">${t.name}</h4>
            ${t.verified ? '<i class="fas fa-check-circle text-blue-500 text-sm flex-shrink-0" title="Verified"></i>' : ''}
          </div>
          <p class="text-xs text-gray-400 mb-2"><i class="fas fa-map-marker-alt mr-1"></i>${t.dist} away</p>
          <div class="flex items-center gap-3 mb-3">
            <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">${t.speciality}</span>
            <span class="flex items-center gap-1 text-xs"><i class="fas fa-star text-yellow-400"></i>${t.rating}</span>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-xs text-gray-400">${t.deals} deals completed</span>
            <button class="btn-primary text-white text-xs px-4 py-1.5 rounded-lg font-medium">Contact</button>
          </div>
        </div>
      </div>
    </div>
  `).join('');

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h3 class="text-lg font-bold text-gray-800">Find Traders</h3>
        <p class="text-sm text-gray-400">Connect with verified traders near you</p>
      </div>
    </div>
    <div class="bg-white rounded-2xl p-4 border border-gray-100">
      <div class="flex flex-wrap gap-3">
        <div class="relative flex-1 min-w-[200px]">
          <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
          <input type="text" placeholder="Search traders..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500">
        </div>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>All Specialities</option><option>Grains</option><option>Vegetables</option><option>Fruits</option><option>Spices</option>
        </select>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>Sort by Distance</option><option>Sort by Rating</option><option>Sort by Deals</option>
        </select>
      </div>
    </div>
    <div class="grid md:grid-cols-2 gap-4">
      ${traderCards}
    </div>
  </div>`;

  return dashboardLayout('Find Traders', 'farmer', body, 'traders');
}

export function farmerOrders(): string {
  const orders = [
    { id: '#ORD-2481', crop: 'Wheat', buyer: 'Rajan Traders', qty: '500 kg', amount: '12,500', date: 'Mar 28', status: 'delivered', color: 'green' },
    { id: '#ORD-2480', crop: 'Rice', buyer: 'Krishna Agro', qty: '1000 kg', amount: '32,000', date: 'Mar 27', status: 'in-transit', color: 'amber' },
    { id: '#ORD-2479', crop: 'Tomatoes', buyer: 'Fresh Mart', qty: '200 kg', amount: '8,000', date: 'Mar 26', status: 'processing', color: 'blue' },
    { id: '#ORD-2478', crop: 'Onions', buyer: 'Metro Wholesale', qty: '800 kg', amount: '16,000', date: 'Mar 25', status: 'delivered', color: 'green' },
    { id: '#ORD-2477', crop: 'Potatoes', buyer: 'Sahyadri Traders', qty: '600 kg', amount: '12,000', date: 'Mar 24', status: 'delivered', color: 'green' },
    { id: '#ORD-2476', crop: 'Chillies', buyer: 'Deccan Hub', qty: '100 kg', amount: '6,000', date: 'Mar 23', status: 'cancelled', color: 'red' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl p-4 border border-gray-100">
        <p class="text-sm text-gray-400">Total Orders</p>
        <p class="text-2xl font-bold text-gray-800 mt-1">156</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100">
        <p class="text-sm text-gray-400">Pending</p>
        <p class="text-2xl font-bold text-amber-600 mt-1">18</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100">
        <p class="text-sm text-gray-400">Completed</p>
        <p class="text-2xl font-bold text-green-600 mt-1">132</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100">
        <p class="text-sm text-gray-400">Total Revenue</p>
        <p class="text-2xl font-bold text-primary-600 mt-1">&#8377;2.4L</p>
      </div>
    </div>

    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-800">Order History</h3>
        <div class="flex gap-2">
          <select class="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none">
            <option>All Status</option><option>Delivered</option><option>In Transit</option><option>Processing</option>
          </select>
        </div>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead>
            <tr class="text-left text-gray-400 border-b border-gray-100">
              <th class="pb-3 font-medium">Order ID</th>
              <th class="pb-3 font-medium">Crop</th>
              <th class="pb-3 font-medium">Buyer</th>
              <th class="pb-3 font-medium">Qty</th>
              <th class="pb-3 font-medium">Amount</th>
              <th class="pb-3 font-medium">Date</th>
              <th class="pb-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-50">
            ${orders.map(o => `
              <tr class="hover:bg-gray-50 transition">
                <td class="py-3 font-medium text-gray-800">${o.id}</td>
                <td class="py-3">${o.crop}</td>
                <td class="py-3 text-gray-600">${o.buyer}</td>
                <td class="py-3 text-gray-600">${o.qty}</td>
                <td class="py-3 font-medium">&#8377;${o.amount}</td>
                <td class="py-3 text-gray-400">${o.date}</td>
                <td class="py-3"><span class="bg-${o.color}-100 text-${o.color}-700 text-xs px-2.5 py-1 rounded-full font-medium">${o.status}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  </div>`;

  return dashboardLayout('Orders & Earnings', 'farmer', body, 'orders');
}

export function farmerDelivery(): string {
  const deliveries = [
    { id: 'DEL-1024', order: '#ORD-2480', buyer: 'Krishna Agro', from: 'Nashik Farm', to: 'Pune Market', status: 'in-transit', progress: 65, driver: 'Suresh Kumar', vehicle: 'MH-15 AB 1234', eta: '2 hrs' },
    { id: 'DEL-1023', order: '#ORD-2479', buyer: 'Fresh Mart', from: 'Nashik Farm', to: 'Mumbai APMC', status: 'picked-up', progress: 30, driver: 'Ramesh Patil', vehicle: 'MH-15 CD 5678', eta: '5 hrs' },
    { id: 'DEL-1022', order: '#ORD-2478', buyer: 'Metro Wholesale', from: 'Nashik Farm', to: 'Nashik Mandi', status: 'delivered', progress: 100, driver: 'Amit Shah', vehicle: 'MH-15 EF 9012', eta: 'Delivered' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid sm:grid-cols-3 gap-4">
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-truck text-amber-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">2</p>
        <p class="text-xs text-gray-400">In Transit</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-check-circle text-green-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">48</p>
        <p class="text-xs text-gray-400">Delivered</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-box text-blue-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">3</p>
        <p class="text-xs text-gray-400">Awaiting Pickup</p>
      </div>
    </div>

    <div class="space-y-4">
      ${deliveries.map(d => `
        <div class="bg-white rounded-2xl p-6 border border-gray-100 card-hover">
          <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div>
              <div class="flex items-center gap-2 mb-1">
                <span class="font-bold text-gray-800">${d.id}</span>
                <span class="text-xs bg-${d.status === 'delivered' ? 'green' : d.status === 'in-transit' ? 'amber' : 'blue'}-100 text-${d.status === 'delivered' ? 'green' : d.status === 'in-transit' ? 'amber' : 'blue'}-700 px-2 py-0.5 rounded-full">${d.status}</span>
              </div>
              <p class="text-sm text-gray-400">Order: ${d.order} | Buyer: ${d.buyer}</p>
            </div>
            <div class="text-right">
              <p class="text-sm font-medium text-gray-800">ETA: ${d.eta}</p>
              <p class="text-xs text-gray-400">${d.driver} | ${d.vehicle}</p>
            </div>
          </div>
          <div class="flex items-center gap-4 mb-2">
            <span class="text-xs text-gray-500 w-24 text-right">${d.from}</span>
            <div class="flex-1">
              <div class="w-full bg-gray-100 rounded-full h-2">
                <div class="bg-primary-500 rounded-full h-2 transition-all" style="width:${d.progress}%"></div>
              </div>
            </div>
            <span class="text-xs text-gray-500 w-24">${d.to}</span>
          </div>
          <div class="flex justify-center">
            <span class="text-xs text-gray-400">${d.progress}% complete</span>
          </div>
        </div>
      `).join('')}
    </div>
  </div>`;

  return dashboardLayout('Delivery Management', 'farmer', body, 'delivery');
}
