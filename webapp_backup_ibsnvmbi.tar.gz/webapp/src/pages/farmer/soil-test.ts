import { dashboardLayout } from '../../layout';

export function farmerSoilTest(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid lg:grid-cols-2 gap-6">
      <!-- Upload Section -->
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-1">AI Soil Analysis</h3>
        <p class="text-sm text-gray-400 mb-6">Upload a soil sample image for instant AI-powered analysis</p>
        
        <div id="uploadArea" class="border-2 border-dashed border-gray-200 rounded-2xl p-10 text-center cursor-pointer hover:border-primary-300 transition mb-4" onclick="document.getElementById('soilFileInput').click()">
          <div id="uploadPlaceholder">
            <div class="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <i class="fas fa-camera text-primary-500 text-2xl"></i>
            </div>
            <p class="font-medium text-gray-700 mb-1">Upload Soil Image</p>
            <p class="text-sm text-gray-400">Take a clear photo of your soil sample</p>
            <p class="text-xs text-gray-300 mt-2">PNG, JPG up to 10MB</p>
          </div>
          <div id="uploadPreview" class="hidden">
            <div class="w-24 h-24 bg-earth-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
              <i class="fas fa-check-circle text-primary-500 text-3xl"></i>
            </div>
            <p class="font-medium text-gray-700">Image uploaded!</p>
            <p class="text-sm text-gray-400">Click to change</p>
          </div>
          <input type="file" id="soilFileInput" class="hidden" accept="image/*" onchange="handleSoilUpload(this)">
        </div>
        
        <div class="space-y-3 mb-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Farm Location</label>
            <input type="text" placeholder="e.g., Village Koraput, Dist. Nashik" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Soil Type</label>
              <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none">
                <option>Select type</option>
                <option>Alluvial</option>
                <option>Black / Regur</option>
                <option>Red Soil</option>
                <option>Laterite</option>
                <option>Sandy</option>
                <option>Clay</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Current Crop</label>
              <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none">
                <option>Select crop</option>
                <option>Wheat</option>
                <option>Rice</option>
                <option>Cotton</option>
                <option>Sugarcane</option>
                <option>Vegetables</option>
              </select>
            </div>
          </div>
        </div>
        
        <button onclick="runSoilAnalysis()" class="btn-primary w-full text-white py-3 rounded-xl font-medium text-sm inline-flex items-center justify-center gap-2">
          <i class="fas fa-brain"></i> Run AI Analysis
        </button>
      </div>

      <!-- Results Section -->
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Analysis Report</h3>
        
        <div id="analysisLoading" class="hidden text-center py-12">
          <div class="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p class="text-gray-500">Analyzing your soil sample...</p>
        </div>
        
        <div id="analysisPlaceholder" class="text-center py-12">
          <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-flask text-gray-300 text-2xl"></i>
          </div>
          <p class="text-gray-400">Upload a soil image and run analysis to see results here</p>
        </div>
        
        <div id="analysisResult" class="hidden space-y-4">
          <!-- Health Score -->
          <div class="bg-primary-50 rounded-xl p-4 text-center">
            <p class="text-sm text-gray-500 mb-1">Overall Soil Health</p>
            <p class="text-4xl font-bold text-primary-600">78<span class="text-lg">/100</span></p>
            <p class="text-sm text-primary-600 mt-1">Good Condition</p>
          </div>
          
          <!-- Nutrient Levels -->
          <div>
            <p class="text-sm font-medium text-gray-700 mb-3">Nutrient Levels</p>
            <div class="space-y-3">
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-gray-600">Nitrogen (N)</span><span class="font-medium text-primary-600">High - 280 kg/ha</span></div>
                <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-primary-500 rounded-full h-2" style="width:85%"></div></div>
              </div>
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-gray-600">Phosphorus (P)</span><span class="font-medium text-amber-600">Medium - 18 kg/ha</span></div>
                <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:55%"></div></div>
              </div>
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-gray-600">Potassium (K)</span><span class="font-medium text-primary-600">High - 320 kg/ha</span></div>
                <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-primary-500 rounded-full h-2" style="width:80%"></div></div>
              </div>
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-gray-600">pH Level</span><span class="font-medium text-blue-600">6.8 (Neutral)</span></div>
                <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-blue-500 rounded-full h-2" style="width:68%"></div></div>
              </div>
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-gray-600">Organic Carbon</span><span class="font-medium text-amber-600">Medium - 0.52%</span></div>
                <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:52%"></div></div>
              </div>
            </div>
          </div>
          
          <!-- Recommendations -->
          <div>
            <p class="text-sm font-medium text-gray-700 mb-3">AI Recommendations</p>
            <div class="space-y-2">
              <div class="flex items-start gap-3 p-3 bg-green-50 rounded-xl">
                <i class="fas fa-check-circle text-green-500 mt-0.5"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Suitable for Wheat & Rice</p>
                  <p class="text-xs text-gray-500">Current soil conditions are optimal for cereal crops.</p>
                </div>
              </div>
              <div class="flex items-start gap-3 p-3 bg-amber-50 rounded-xl">
                <i class="fas fa-exclamation-circle text-amber-500 mt-0.5"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Add Phosphorus Fertilizer</p>
                  <p class="text-xs text-gray-500">Apply DAP or SSP at 50 kg/ha before sowing for better yield.</p>
                </div>
              </div>
              <div class="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
                <i class="fas fa-info-circle text-blue-500 mt-0.5"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Increase Organic Matter</p>
                  <p class="text-xs text-gray-500">Add farmyard manure (FYM) at 10 tons/ha to improve carbon content.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div class="flex gap-3 pt-2">
            <button class="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 rounded-xl text-sm font-medium transition"><i class="fas fa-download mr-2"></i>Download PDF</button>
            <a href="/farmer/pesticide" class="flex-1 btn-primary text-white py-2.5 rounded-xl text-sm font-medium text-center"><i class="fas fa-brain mr-2"></i>AI Suggestions</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Previous Reports -->
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <h3 class="font-bold text-gray-800 mb-4">Previous Reports</h3>
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="border border-gray-100 rounded-xl p-4 card-hover">
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">Field A</span>
            <span class="text-xs text-gray-400">Mar 15, 2026</span>
          </div>
          <p class="font-medium text-gray-800 mb-1">Alluvial Soil</p>
          <p class="text-sm text-gray-500 mb-3">Health Score: <span class="text-primary-600 font-bold">82/100</span></p>
          <button class="text-xs text-primary-600 hover:underline font-medium">View Report</button>
        </div>
        <div class="border border-gray-100 rounded-xl p-4 card-hover">
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full">Field B</span>
            <span class="text-xs text-gray-400">Feb 28, 2026</span>
          </div>
          <p class="font-medium text-gray-800 mb-1">Black Soil</p>
          <p class="text-sm text-gray-500 mb-3">Health Score: <span class="text-amber-600 font-bold">65/100</span></p>
          <button class="text-xs text-primary-600 hover:underline font-medium">View Report</button>
        </div>
        <div class="border border-gray-100 rounded-xl p-4 card-hover">
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Field C</span>
            <span class="text-xs text-gray-400">Jan 10, 2026</span>
          </div>
          <p class="font-medium text-gray-800 mb-1">Red Soil</p>
          <p class="text-sm text-gray-500 mb-3">Health Score: <span class="text-primary-600 font-bold">74/100</span></p>
          <button class="text-xs text-primary-600 hover:underline font-medium">View Report</button>
        </div>
      </div>
    </div>
  </div>

  <script>
  function handleSoilUpload(input) {
    if (input.files && input.files[0]) {
      document.getElementById('uploadPlaceholder').classList.add('hidden');
      document.getElementById('uploadPreview').classList.remove('hidden');
    }
  }
  function runSoilAnalysis() {
    document.getElementById('analysisPlaceholder').classList.add('hidden');
    document.getElementById('analysisResult').classList.add('hidden');
    document.getElementById('analysisLoading').classList.remove('hidden');
    setTimeout(function() {
      document.getElementById('analysisLoading').classList.add('hidden');
      document.getElementById('analysisResult').classList.remove('hidden');
    }, 2500);
  }
  </script>`;

  return dashboardLayout('Soil Testing', 'farmer', body, 'soil-test');
}
