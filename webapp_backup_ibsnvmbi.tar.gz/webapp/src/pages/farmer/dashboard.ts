import { dashboardLayout } from '../../layout';

export function farmerDashboard(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <!-- Stats Row -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-leaf text-primary-600"></i>
          </div>
          <span class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full font-medium">+12%</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">24</p>
        <p class="text-sm text-gray-400">Active Crops</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-clipboard-list text-amber-600"></i>
          </div>
          <span class="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-full font-medium">5 new</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">18</p>
        <p class="text-sm text-gray-400">Pending Orders</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-rupee-sign text-blue-600"></i>
          </div>
          <span class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full font-medium">+8%</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">&#8377;2.4L</p>
        <p class="text-sm text-gray-400">Total Earnings</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-users text-purple-600"></i>
          </div>
        </div>
        <p class="text-2xl font-bold text-gray-800">7</p>
        <p class="text-sm text-gray-400">Connected Traders</p>
      </div>
    </div>

    <!-- Charts & Recent Activity -->
    <div class="grid lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-6">
          <h3 class="font-bold text-gray-800">Market Price Trends</h3>
          <select class="text-sm border border-gray-200 rounded-lg px-3 py-1.5 text-gray-600 outline-none">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 3 months</option>
          </select>
        </div>
        <canvas id="priceChart" height="200"></canvas>
      </div>
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-3">
          <a href="/farmer/crops" class="flex items-center gap-3 p-3 rounded-xl bg-primary-50 hover:bg-primary-100 transition group">
            <div class="w-9 h-9 bg-primary-200 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <i class="fas fa-plus text-primary-700 text-sm"></i>
            </div>
            <div>
              <p class="text-sm font-medium text-gray-800">Add New Crop</p>
              <p class="text-xs text-gray-400">List your produce</p>
            </div>
          </a>
          <a href="/farmer/soil-test" class="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 transition group">
            <div class="w-9 h-9 bg-blue-200 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <i class="fas fa-flask text-blue-700 text-sm"></i>
            </div>
            <div>
              <p class="text-sm font-medium text-gray-800">Soil Test</p>
              <p class="text-xs text-gray-400">AI-powered analysis</p>
            </div>
          </a>
          <a href="/farmer/lab-finder" class="flex items-center gap-3 p-3 rounded-xl bg-amber-50 hover:bg-amber-100 transition group">
            <div class="w-9 h-9 bg-amber-200 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <i class="fas fa-map-marker-alt text-amber-700 text-sm"></i>
            </div>
            <div>
              <p class="text-sm font-medium text-gray-800">Find Lab</p>
              <p class="text-xs text-gray-400">Nearby testing labs</p>
            </div>
          </a>
          <a href="/farmer/pesticide" class="flex items-center gap-3 p-3 rounded-xl bg-purple-50 hover:bg-purple-100 transition group">
            <div class="w-9 h-9 bg-purple-200 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <i class="fas fa-brain text-purple-700 text-sm"></i>
            </div>
            <div>
              <p class="text-sm font-medium text-gray-800">AI Suggestions</p>
              <p class="text-xs text-gray-400">Pesticide & fertilizer</p>
            </div>
          </a>
        </div>
      </div>
    </div>

    <!-- Recent Orders -->
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-800">Recent Orders</h3>
        <a href="/farmer/orders" class="text-sm text-primary-600 hover:underline font-medium">View All</a>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead>
            <tr class="text-left text-gray-400 border-b border-gray-100">
              <th class="pb-3 font-medium">Order ID</th>
              <th class="pb-3 font-medium">Crop</th>
              <th class="pb-3 font-medium">Buyer</th>
              <th class="pb-3 font-medium">Qty</th>
              <th class="pb-3 font-medium">Amount</th>
              <th class="pb-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-50">
            <tr class="hover:bg-gray-50 transition">
              <td class="py-3 font-medium text-gray-800">#ORD-2481</td>
              <td class="py-3"><span class="inline-flex items-center gap-1"><i class="fas fa-seedling text-primary-400 text-xs"></i> Wheat</span></td>
              <td class="py-3 text-gray-600">Rajan Traders</td>
              <td class="py-3 text-gray-600">500 kg</td>
              <td class="py-3 font-medium">&#8377;12,500</td>
              <td class="py-3"><span class="bg-green-100 text-green-700 text-xs px-2.5 py-1 rounded-full font-medium">Delivered</span></td>
            </tr>
            <tr class="hover:bg-gray-50 transition">
              <td class="py-3 font-medium text-gray-800">#ORD-2480</td>
              <td class="py-3"><span class="inline-flex items-center gap-1"><i class="fas fa-seedling text-primary-400 text-xs"></i> Rice</span></td>
              <td class="py-3 text-gray-600">Krishna Agro</td>
              <td class="py-3 text-gray-600">1000 kg</td>
              <td class="py-3 font-medium">&#8377;32,000</td>
              <td class="py-3"><span class="bg-amber-100 text-amber-700 text-xs px-2.5 py-1 rounded-full font-medium">In Transit</span></td>
            </tr>
            <tr class="hover:bg-gray-50 transition">
              <td class="py-3 font-medium text-gray-800">#ORD-2479</td>
              <td class="py-3"><span class="inline-flex items-center gap-1"><i class="fas fa-seedling text-primary-400 text-xs"></i> Tomatoes</span></td>
              <td class="py-3 text-gray-600">Fresh Mart</td>
              <td class="py-3 text-gray-600">200 kg</td>
              <td class="py-3 font-medium">&#8377;8,000</td>
              <td class="py-3"><span class="bg-blue-100 text-blue-700 text-xs px-2.5 py-1 rounded-full font-medium">Processing</span></td>
            </tr>
            <tr class="hover:bg-gray-50 transition">
              <td class="py-3 font-medium text-gray-800">#ORD-2478</td>
              <td class="py-3"><span class="inline-flex items-center gap-1"><i class="fas fa-seedling text-primary-400 text-xs"></i> Onions</span></td>
              <td class="py-3 text-gray-600">Metro Wholesale</td>
              <td class="py-3 text-gray-600">800 kg</td>
              <td class="py-3 font-medium">&#8377;16,000</td>
              <td class="py-3"><span class="bg-green-100 text-green-700 text-xs px-2.5 py-1 rounded-full font-medium">Delivered</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Crop Health Overview -->
    <div class="grid md:grid-cols-2 gap-6">
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Soil Health Summary</h3>
        <canvas id="soilChart" height="200"></canvas>
      </div>
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Top Crops Performance</h3>
        <div class="space-y-4">
          <div>
            <div class="flex justify-between text-sm mb-1"><span class="text-gray-600">Wheat</span><span class="font-medium">85%</span></div>
            <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-primary-500 rounded-full h-2" style="width:85%"></div></div>
          </div>
          <div>
            <div class="flex justify-between text-sm mb-1"><span class="text-gray-600">Rice</span><span class="font-medium">72%</span></div>
            <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-blue-500 rounded-full h-2" style="width:72%"></div></div>
          </div>
          <div>
            <div class="flex justify-between text-sm mb-1"><span class="text-gray-600">Tomatoes</span><span class="font-medium">90%</span></div>
            <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:90%"></div></div>
          </div>
          <div>
            <div class="flex justify-between text-sm mb-1"><span class="text-gray-600">Onions</span><span class="font-medium">68%</span></div>
            <div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-purple-500 rounded-full h-2" style="width:68%"></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    // Price Trend Chart
    const priceCtx = document.getElementById('priceChart');
    if (priceCtx) {
      new Chart(priceCtx, {
        type: 'line',
        data: {
          labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
          datasets: [
            { label: 'Wheat', data: [25,26,24,27,28,26,29], borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.1)', fill: true, tension: 0.4 },
            { label: 'Rice', data: [32,31,33,35,34,36,35], borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.1)', fill: true, tension: 0.4 },
            { label: 'Tomatoes', data: [40,42,38,45,43,41,44], borderColor: '#f59e0b', backgroundColor: 'rgba(245,158,11,0.1)', fill: true, tension: 0.4 }
          ]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 20 } } }, scales: { y: { beginAtZero: false, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
      });
    }
    // Soil Chart
    const soilCtx = document.getElementById('soilChart');
    if (soilCtx) {
      new Chart(soilCtx, {
        type: 'radar',
        data: {
          labels: ['Nitrogen','Phosphorus','Potassium','pH Level','Organic Matter','Moisture'],
          datasets: [{ label: 'Current', data: [75,60,80,70,65,85], backgroundColor: 'rgba(34,197,94,0.2)', borderColor: '#22c55e', pointBackgroundColor: '#22c55e' }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { r: { beginAtZero: true, max: 100 } } }
      });
    }
  });
  </script>`;

  return dashboardLayout('Dashboard', 'farmer', body, 'dashboard');
}
