import { dashboardLayout } from '../../layout';

export function farmerLabFinder(): string {
  const labs = [
    { name: 'State Soil Testing Lab', dist: '2.3 km', rating: 4.8, reviews: 124, addr: 'Agricultural University Campus, Nashik', phone: '+91 98765 43210', services: ['NPK Analysis','pH Testing','Organic Carbon','Micronutrients'], price: 250, avail: 'Mon-Sat, 9AM-5PM', booked: false },
    { name: 'KrishiLab Agro Services', dist: '5.1 km', rating: 4.5, reviews: 89, addr: 'Market Yard Road, Nashik', phone: '+91 87654 32109', services: ['NPK Analysis','pH Testing','Water Analysis','Soil Health Card'], price: 350, avail: 'Mon-Fri, 10AM-6PM', booked: false },
    { name: 'GreenEarth Lab Pvt Ltd', dist: '8.7 km', rating: 4.7, reviews: 156, addr: 'MIDC Industrial Area, Nashik', phone: '+91 76543 21098', services: ['Complete Soil Profile','Heavy Metal Testing','Fertility Index','Pesticide Residue'], price: 500, avail: 'All Days, 8AM-8PM', booked: true },
    { name: 'District Agriculture Office Lab', dist: '3.5 km', rating: 4.2, reviews: 67, addr: 'Collectorate Office, Nashik', phone: '+91 65432 10987', services: ['NPK Analysis','pH Testing','Free for Farmers'], price: 0, avail: 'Mon-Fri, 10AM-4PM', booked: false },
  ];

  const labCards = labs.map((l, i) => `
    <div class="bg-white rounded-2xl border border-gray-100 p-5 card-hover">
      <div class="flex items-start justify-between mb-3">
        <div>
          <h4 class="font-bold text-gray-800">${l.name}</h4>
          <p class="text-xs text-gray-400 mt-1"><i class="fas fa-map-marker-alt text-primary-400 mr-1"></i>${l.addr}</p>
        </div>
        <span class="text-xs bg-primary-50 text-primary-700 px-2 py-1 rounded-full whitespace-nowrap">${l.dist}</span>
      </div>
      <div class="flex items-center gap-3 mb-3">
        <div class="flex items-center gap-1">
          <i class="fas fa-star text-yellow-400 text-xs"></i>
          <span class="text-sm font-medium">${l.rating}</span>
          <span class="text-xs text-gray-400">(${l.reviews})</span>
        </div>
        <span class="text-xs text-gray-300">|</span>
        <span class="text-xs text-gray-500"><i class="fas fa-clock mr-1"></i>${l.avail}</span>
      </div>
      <div class="flex flex-wrap gap-1.5 mb-4">
        ${l.services.map(s => '<span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">' + s + '</span>').join('')}
      </div>
      <div class="flex items-center justify-between">
        <span class="font-bold ${l.price === 0 ? 'text-green-600' : 'text-gray-800'}">${l.price === 0 ? 'FREE' : '&#8377;' + l.price}</span>
        ${l.booked ? '<span class="text-xs bg-green-100 text-green-700 px-3 py-1.5 rounded-lg font-medium"><i class="fas fa-check mr-1"></i>Booked</span>' : '<button onclick="bookLab(' + i + ')" class="btn-primary text-white text-xs px-4 py-1.5 rounded-lg font-medium">Book Now</button>'}
      </div>
    </div>
  `).join('');

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h3 class="text-lg font-bold text-gray-800">Soil Testing Labs Near You</h3>
        <p class="text-sm text-gray-400">Find and book appointments at nearby testing facilities</p>
      </div>
    </div>

    <!-- Search & Filter -->
    <div class="bg-white rounded-2xl p-4 border border-gray-100">
      <div class="flex flex-wrap gap-3">
        <div class="relative flex-1 min-w-[200px]">
          <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
          <input type="text" placeholder="Search labs by name or location..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500">
        </div>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>Sort by Distance</option>
          <option>Sort by Rating</option>
          <option>Sort by Price</option>
        </select>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>All Services</option>
          <option>NPK Analysis</option>
          <option>pH Testing</option>
          <option>Water Analysis</option>
        </select>
      </div>
    </div>

    <!-- Map Placeholder -->
    <div class="bg-white rounded-2xl border border-gray-100 overflow-hidden">
      <div class="h-48 bg-gradient-to-br from-primary-50 to-blue-50 flex items-center justify-center">
        <div class="text-center">
          <i class="fas fa-map-marked-alt text-primary-300 text-4xl mb-2"></i>
          <p class="text-sm text-gray-400">Interactive map showing nearby labs</p>
          <p class="text-xs text-gray-300 mt-1">Nashik, Maharashtra (Demo Location)</p>
        </div>
      </div>
    </div>

    <!-- Lab Cards -->
    <div class="grid md:grid-cols-2 gap-4">
      ${labCards}
    </div>

    <!-- Booking Modal -->
    <div id="bookingModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl w-full max-w-md p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-bold text-gray-800">Book Appointment</h3>
          <button onclick="closeBookingModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <form onsubmit="confirmBooking(event)" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Preferred Date</label>
            <input type="date" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary-500" required>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Preferred Time</label>
            <select class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none" required>
              <option>9:00 AM</option><option>10:00 AM</option><option>11:00 AM</option>
              <option>2:00 PM</option><option>3:00 PM</option><option>4:00 PM</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tests Required</label>
            <div class="space-y-2">
              <label class="flex items-center gap-2"><input type="checkbox" class="rounded text-primary-500" checked> <span class="text-sm">NPK Analysis</span></label>
              <label class="flex items-center gap-2"><input type="checkbox" class="rounded text-primary-500"> <span class="text-sm">pH Testing</span></label>
              <label class="flex items-center gap-2"><input type="checkbox" class="rounded text-primary-500"> <span class="text-sm">Organic Carbon</span></label>
              <label class="flex items-center gap-2"><input type="checkbox" class="rounded text-primary-500"> <span class="text-sm">Micronutrients</span></label>
            </div>
          </div>
          <div class="flex gap-3 pt-2">
            <button type="button" onclick="closeBookingModal()" class="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">Cancel</button>
            <button type="submit" class="flex-1 btn-primary text-white py-2.5 rounded-xl text-sm font-medium">Confirm Booking</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
  function bookLab(index) { document.getElementById('bookingModal').classList.remove('hidden'); }
  function closeBookingModal() { document.getElementById('bookingModal').classList.add('hidden'); }
  function confirmBooking(e) {
    e.preventDefault();
    closeBookingModal();
    showToast('Booking confirmed! You will receive a confirmation SMS.');
  }
  </script>`;

  return dashboardLayout('Lab Finder', 'farmer', body, 'lab-finder');
}
