import { dashboardLayout } from '../../layout';

export function buyerBrowse(): string {
  const products = [
    { id: 1, name: 'Organic Wheat', seller: 'Ramesh Farm', sellerType: 'Farmer', price: 35, unit: 'kg', rating: 4.8, organic: true },
    { id: 2, name: 'Basmati Rice (Premium)', seller: 'Krishna Wholesale', sellerType: 'Trader', price: 80, unit: 'kg', rating: 4.6, organic: false },
    { id: 3, name: 'Fresh Tomatoes', seller: 'Sunil Farms', sellerType: 'Farmer', price: 40, unit: 'kg', rating: 4.5, organic: true },
    { id: 4, name: 'Red Onions', seller: 'Sahyadri Traders', sellerType: 'Trader', price: 30, unit: 'kg', rating: 4.3, organic: false },
    { id: 5, name: 'Green Chillies', seller: 'Priya Farm', sellerType: 'Farmer', price: 60, unit: 'kg', rating: 4.7, organic: true },
    { id: 6, name: 'Potatoes (Grade A)', seller: 'Metro Agri', sellerType: 'Trader', price: 25, unit: 'kg', rating: 4.4, organic: false },
    { id: 7, name: 'Alphonso Mangoes', seller: 'Meera Sawant Farm', sellerType: 'Farmer', price: 400, unit: 'dozen', rating: 4.9, organic: true },
    { id: 8, name: 'Brown Rice', seller: 'Deccan Hub', sellerType: 'Trader', price: 70, unit: 'kg', rating: 4.2, organic: true },
    { id: 9, name: 'Fresh Coriander', seller: 'Ganesh Farm', sellerType: 'Farmer', price: 30, unit: 'bunch', rating: 4.6, organic: true },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <!-- Search Bar -->
    <div class="bg-white rounded-2xl p-4 border border-gray-100">
      <div class="flex flex-wrap gap-3">
        <div class="relative flex-1 min-w-[250px]">
          <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
          <input type="text" placeholder="Search for fresh vegetables, grains, fruits..." class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <select class="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none">
          <option>All Categories</option><option>Grains</option><option>Vegetables</option><option>Fruits</option><option>Spices</option><option>Pulses</option>
        </select>
        <select class="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none">
          <option>All Sellers</option><option>Farmers Only</option><option>Traders Only</option>
        </select>
        <select class="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none">
          <option>Sort: Relevance</option><option>Price: Low to High</option><option>Price: High to Low</option><option>Rating</option>
        </select>
      </div>
      <div class="flex flex-wrap gap-2 mt-3">
        <button class="text-xs bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full font-medium">All</button>
        <button class="text-xs bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full hover:bg-blue-50 transition">Organic</button>
        <button class="text-xs bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full hover:bg-blue-50 transition">Farm Direct</button>
        <button class="text-xs bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full hover:bg-blue-50 transition">Under &#8377;50</button>
        <button class="text-xs bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full hover:bg-blue-50 transition">Near Me</button>
      </div>
    </div>

    <!-- Products Grid -->
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      ${products.map(p => `
        <div class="bg-white rounded-2xl border border-gray-100 overflow-hidden card-hover">
          <div class="h-36 bg-gradient-to-br from-blue-50 to-primary-50 flex items-center justify-center relative">
            <i class="fas fa-seedling text-primary-300 text-4xl"></i>
            ${p.organic ? '<span class="absolute top-3 left-3 text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">Organic</span>' : ''}
            <span class="absolute top-3 right-3 text-xs bg-white/80 text-gray-600 px-2 py-0.5 rounded-full">${p.sellerType}</span>
          </div>
          <div class="p-4">
            <h4 class="font-bold text-gray-800 mb-1">${p.name}</h4>
            <p class="text-xs text-gray-400 mb-2"><i class="fas fa-store mr-1"></i>${p.seller}</p>
            <div class="flex items-center gap-2 mb-3">
              <span class="flex items-center gap-1 text-xs"><i class="fas fa-star text-yellow-400"></i>${p.rating}</span>
              <span class="text-xs text-gray-300">|</span>
              <span class="text-xs text-gray-400">Free delivery</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-lg font-bold text-blue-600">&#8377;${p.price}<span class="text-xs text-gray-400 font-normal">/${p.unit}</span></span>
              <button onclick="addToCart(${p.id})" class="bg-blue-500 hover:bg-blue-600 text-white text-xs px-4 py-2 rounded-xl font-medium transition inline-flex items-center gap-1">
                <i class="fas fa-cart-plus"></i> Add
              </button>
            </div>
          </div>
        </div>
      `).join('')}
    </div>

    <!-- Load More -->
    <div class="text-center">
      <button class="bg-white border border-gray-200 text-gray-600 px-8 py-3 rounded-xl text-sm font-medium hover:bg-gray-50 transition">
        Load More Products
      </button>
    </div>
  </div>`;

  return dashboardLayout('Browse Products', 'buyer', body, 'browse');
}

export function buyerCart(): string {
  const cartItems = [
    { id: 1, name: 'Organic Wheat', seller: 'Ramesh Farm', price: 35, qty: 10, unit: 'kg' },
    { id: 2, name: 'Fresh Tomatoes', seller: 'Sunil Farms', price: 40, qty: 5, unit: 'kg' },
    { id: 3, name: 'Red Onions', seller: 'Sahyadri Traders', price: 30, qty: 8, unit: 'kg' },
  ];

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const delivery = 49;
  const total = subtotal + delivery;

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid lg:grid-cols-3 gap-6">
      <!-- Cart Items -->
      <div class="lg:col-span-2 space-y-4">
        <div class="bg-white rounded-2xl p-6 border border-gray-100">
          <h3 class="font-bold text-gray-800 mb-4">Shopping Cart (${cartItems.length} items)</h3>
          <div class="space-y-4">
            ${cartItems.map(item => `
              <div class="flex items-center gap-4 p-4 border border-gray-100 rounded-xl">
                <div class="w-16 h-16 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0">
                  <i class="fas fa-seedling text-primary-400 text-xl"></i>
                </div>
                <div class="flex-1 min-w-0">
                  <h4 class="font-bold text-gray-800 text-sm">${item.name}</h4>
                  <p class="text-xs text-gray-400">${item.seller}</p>
                  <p class="text-sm font-bold text-blue-600 mt-1">&#8377;${item.price}/${item.unit}</p>
                </div>
                <div class="flex items-center gap-2">
                  <button class="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition text-sm">-</button>
                  <span class="w-10 text-center font-medium text-sm">${item.qty}</span>
                  <button class="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition text-sm">+</button>
                </div>
                <div class="text-right">
                  <p class="font-bold text-gray-800">&#8377;${item.price * item.qty}</p>
                  <button class="text-xs text-red-500 hover:underline mt-1">Remove</button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Order Summary -->
      <div>
        <div class="bg-white rounded-2xl p-6 border border-gray-100 sticky top-4">
          <h3 class="font-bold text-gray-800 mb-4">Order Summary</h3>
          <div class="space-y-3 mb-6">
            <div class="flex justify-between text-sm"><span class="text-gray-500">Subtotal</span><span class="font-medium">&#8377;${subtotal}</span></div>
            <div class="flex justify-between text-sm"><span class="text-gray-500">Delivery</span><span class="font-medium">&#8377;${delivery}</span></div>
            <div class="flex justify-between text-sm"><span class="text-gray-500">Discount</span><span class="font-medium text-green-600">-&#8377;0</span></div>
            <div class="border-t border-gray-100 pt-3 flex justify-between"><span class="font-bold text-gray-800">Total</span><span class="font-bold text-lg text-blue-600">&#8377;${total}</span></div>
          </div>
          <div class="mb-4">
            <div class="flex gap-2">
              <input type="text" placeholder="Coupon code" class="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none">
              <button class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2.5 rounded-xl text-sm font-medium transition">Apply</button>
            </div>
          </div>
          <a href="/buyer/checkout" class="bg-blue-500 hover:bg-blue-600 text-white w-full py-3 rounded-xl text-sm font-medium transition block text-center">
            <i class="fas fa-lock mr-2"></i>Proceed to Checkout
          </a>
          <a href="/buyer/browse" class="block text-center text-sm text-gray-500 hover:text-blue-600 mt-3 transition">Continue Shopping</a>
        </div>
      </div>
    </div>
  </div>`;

  return dashboardLayout('My Cart', 'buyer', body, 'cart');
}

export function buyerCheckout(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2 space-y-6">
        <!-- Delivery Address -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100">
          <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-map-marker-alt text-blue-500 mr-2"></i>Delivery Address</h3>
          <div class="grid sm:grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label><input type="text" value="Demo User" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500"></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Phone</label><input type="tel" value="+91 98765 43210" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none"></div>
            <div class="sm:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><input type="text" value="123 Green Street" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none"></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">City</label><input type="text" value="Nashik" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none"></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">PIN Code</label><input type="text" value="422001" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none"></div>
          </div>
        </div>

        <!-- Payment Method -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100">
          <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-credit-card text-blue-500 mr-2"></i>Payment Method</h3>
          <div class="space-y-3">
            <label class="flex items-center gap-3 p-4 border border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition">
              <input type="radio" name="payment" value="upi" class="text-blue-500" checked>
              <div class="flex items-center gap-2"><i class="fas fa-mobile-alt text-blue-500"></i><span class="text-sm font-medium">UPI Payment</span></div>
            </label>
            <label class="flex items-center gap-3 p-4 border border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition">
              <input type="radio" name="payment" value="card" class="text-blue-500">
              <div class="flex items-center gap-2"><i class="fas fa-credit-card text-purple-500"></i><span class="text-sm font-medium">Credit / Debit Card</span></div>
            </label>
            <label class="flex items-center gap-3 p-4 border border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition">
              <input type="radio" name="payment" value="cod" class="text-blue-500">
              <div class="flex items-center gap-2"><i class="fas fa-money-bill text-green-500"></i><span class="text-sm font-medium">Cash on Delivery</span></div>
            </label>
          </div>
        </div>
      </div>

      <!-- Order Summary -->
      <div>
        <div class="bg-white rounded-2xl p-6 border border-gray-100 sticky top-4">
          <h3 class="font-bold text-gray-800 mb-4">Order Summary</h3>
          <div class="space-y-3 mb-4">
            <div class="flex items-center justify-between text-sm"><span class="text-gray-600">Organic Wheat x 10 kg</span><span>&#8377;350</span></div>
            <div class="flex items-center justify-between text-sm"><span class="text-gray-600">Fresh Tomatoes x 5 kg</span><span>&#8377;200</span></div>
            <div class="flex items-center justify-between text-sm"><span class="text-gray-600">Red Onions x 8 kg</span><span>&#8377;240</span></div>
          </div>
          <div class="border-t border-gray-100 pt-3 space-y-2 mb-6">
            <div class="flex justify-between text-sm"><span class="text-gray-500">Subtotal</span><span>&#8377;790</span></div>
            <div class="flex justify-between text-sm"><span class="text-gray-500">Delivery</span><span>&#8377;49</span></div>
            <div class="flex justify-between font-bold text-lg pt-2 border-t border-gray-100"><span>Total</span><span class="text-blue-600">&#8377;839</span></div>
          </div>
          <button onclick="placeOrder()" class="bg-blue-500 hover:bg-blue-600 text-white w-full py-3 rounded-xl text-sm font-medium transition">
            <i class="fas fa-lock mr-2"></i>Place Order
          </button>
          <div class="flex items-center justify-center gap-2 mt-3 text-xs text-gray-400">
            <i class="fas fa-shield-alt"></i>
            <span>Secure payment by AgriMarket</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  function placeOrder() {
    var btn = event.target;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
    btn.disabled = true;
    setTimeout(function() {
      window.location.href = '/buyer/tracking';
    }, 2000);
  }
  </script>`;

  return dashboardLayout('Checkout', 'buyer', body, 'cart');
}

export function buyerOrders(): string {
  const orders = [
    { id: '#BUY-1024', items: 'Organic Wheat, Tomatoes, Onions', total: '839', date: 'Mar 28', status: 'processing', color: 'blue' },
    { id: '#BUY-1023', items: 'Basmati Rice - 5 kg', total: '400', date: 'Mar 25', status: 'in-transit', color: 'amber' },
    { id: '#BUY-1022', items: 'Alphonso Mangoes - 1 dozen', total: '400', date: 'Mar 22', status: 'delivered', color: 'green' },
    { id: '#BUY-1021', items: 'Green Chillies, Potatoes', total: '310', date: 'Mar 18', status: 'delivered', color: 'green' },
    { id: '#BUY-1020', items: 'Brown Rice - 10 kg', total: '700', date: 'Mar 14', status: 'delivered', color: 'green' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-800">My Orders</h3>
        <select class="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none">
          <option>All Orders</option><option>Processing</option><option>In Transit</option><option>Delivered</option>
        </select>
      </div>
      <div class="space-y-3">
        ${orders.map(o => `
          <div class="border border-gray-100 rounded-xl p-4 hover:shadow-sm transition">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div class="flex items-center gap-2 mb-1">
                  <span class="font-bold text-gray-800 text-sm">${o.id}</span>
                  <span class="bg-${o.color}-100 text-${o.color}-700 text-xs px-2 py-0.5 rounded-full font-medium">${o.status}</span>
                </div>
                <p class="text-sm text-gray-600">${o.items}</p>
                <p class="text-xs text-gray-400 mt-1">${o.date}</p>
              </div>
              <div class="flex items-center gap-3">
                <span class="font-bold text-gray-800">&#8377;${o.total}</span>
                ${o.status === 'in-transit' ? '<a href="/buyer/tracking" class="text-xs bg-blue-500 text-white px-3 py-1.5 rounded-lg font-medium">Track</a>' : '<button class="text-xs bg-gray-100 text-gray-600 px-3 py-1.5 rounded-lg font-medium">Details</button>'}
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  </div>`;

  return dashboardLayout('My Orders', 'buyer', body, 'orders');
}

export function buyerTracking(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <!-- Active Tracking -->
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h3 class="font-bold text-gray-800">Order #BUY-1023</h3>
          <p class="text-sm text-gray-400">Basmati Rice - 5 kg from Krishna Wholesale</p>
        </div>
        <span class="bg-amber-100 text-amber-700 text-xs px-3 py-1 rounded-full font-medium">In Transit</span>
      </div>

      <!-- Progress Timeline -->
      <div class="relative mb-8">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs text-gray-500">Seller</span>
          <span class="text-xs text-gray-500">Your Location</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-3 mb-2">
          <div class="bg-gradient-to-r from-blue-500 to-blue-400 rounded-full h-3 transition-all" style="width:60%">
            <div class="w-5 h-5 bg-blue-600 rounded-full border-2 border-white shadow-md float-right -mt-1 relative">
              <div class="absolute -top-8 right-0 bg-blue-600 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap">60% complete</div>
            </div>
          </div>
        </div>
        <p class="text-center text-xs text-gray-400">Estimated delivery: Today, 6:00 PM</p>
      </div>

      <!-- Timeline Steps -->
      <div class="space-y-0">
        <div class="flex gap-4">
          <div class="flex flex-col items-center">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"><i class="fas fa-check text-white text-xs"></i></div>
            <div class="w-0.5 h-12 bg-green-300"></div>
          </div>
          <div class="pb-6"><p class="font-medium text-gray-800 text-sm">Order Placed</p><p class="text-xs text-gray-400">Mar 25, 10:30 AM</p></div>
        </div>
        <div class="flex gap-4">
          <div class="flex flex-col items-center">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"><i class="fas fa-check text-white text-xs"></i></div>
            <div class="w-0.5 h-12 bg-green-300"></div>
          </div>
          <div class="pb-6"><p class="font-medium text-gray-800 text-sm">Order Confirmed</p><p class="text-xs text-gray-400">Mar 25, 11:00 AM - Seller confirmed your order</p></div>
        </div>
        <div class="flex gap-4">
          <div class="flex flex-col items-center">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"><i class="fas fa-check text-white text-xs"></i></div>
            <div class="w-0.5 h-12 bg-green-300"></div>
          </div>
          <div class="pb-6"><p class="font-medium text-gray-800 text-sm">Picked Up</p><p class="text-xs text-gray-400">Mar 26, 8:00 AM - Package picked by delivery partner</p></div>
        </div>
        <div class="flex gap-4">
          <div class="flex flex-col items-center">
            <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center animate-pulse"><i class="fas fa-truck text-white text-xs"></i></div>
            <div class="w-0.5 h-12 bg-gray-200"></div>
          </div>
          <div class="pb-6"><p class="font-medium text-blue-600 text-sm">In Transit</p><p class="text-xs text-gray-400">Mar 26, 2:00 PM - On the way to your location</p></div>
        </div>
        <div class="flex gap-4">
          <div class="flex flex-col items-center">
            <div class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center"><i class="fas fa-home text-gray-400 text-xs"></i></div>
          </div>
          <div><p class="font-medium text-gray-400 text-sm">Delivered</p><p class="text-xs text-gray-300">Expected: Today, 6:00 PM</p></div>
        </div>
      </div>
    </div>

    <!-- Delivery Details -->
    <div class="grid md:grid-cols-2 gap-6">
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Delivery Partner</h3>
        <div class="flex items-center gap-4">
          <div class="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold text-xl">VK</div>
          <div>
            <p class="font-medium text-gray-800">Vijay Kumar</p>
            <p class="text-xs text-gray-400">Vehicle: MH-15 AB 4567</p>
            <p class="text-xs text-gray-400">Phone: +91 87654 32109</p>
          </div>
        </div>
        <button class="mt-4 bg-blue-50 hover:bg-blue-100 text-blue-700 w-full py-2.5 rounded-xl text-sm font-medium transition">
          <i class="fas fa-phone mr-2"></i>Call Delivery Partner
        </button>
      </div>
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Delivery Address</h3>
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0"><i class="fas fa-map-marker-alt text-blue-500"></i></div>
          <div>
            <p class="font-medium text-gray-800">Demo User</p>
            <p class="text-sm text-gray-500">123 Green Street, Nashik, Maharashtra 422001</p>
            <p class="text-xs text-gray-400 mt-1">Phone: +91 98765 43210</p>
          </div>
        </div>
      </div>
    </div>
  </div>`;

  return dashboardLayout('Track Order', 'buyer', body, 'tracking');
}
