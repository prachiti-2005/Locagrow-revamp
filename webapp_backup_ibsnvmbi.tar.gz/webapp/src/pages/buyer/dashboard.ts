import { dashboardLayout } from '../../layout';

export function buyerDashboard(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mb-3"><i class="fas fa-shopping-bag text-blue-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">12</p>
        <p class="text-sm text-gray-400">Total Orders</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center mb-3"><i class="fas fa-truck text-amber-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">3</p>
        <p class="text-sm text-gray-400">In Transit</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mb-3"><i class="fas fa-heart text-green-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">8</p>
        <p class="text-sm text-gray-400">Wishlist</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mb-3"><i class="fas fa-rupee-sign text-purple-600"></i></div>
        <p class="text-2xl font-bold text-gray-800">&#8377;15.2K</p>
        <p class="text-sm text-gray-400">Total Spent</p>
      </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">
      <!-- Recent Orders -->
      <div class="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-4">
          <h3 class="font-bold text-gray-800">Recent Orders</h3>
          <a href="/buyer/orders" class="text-sm text-blue-600 hover:underline font-medium">View All</a>
        </div>
        <div class="space-y-3">
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center"><i class="fas fa-seedling text-primary-600 text-sm"></i></div>
              <div>
                <p class="text-sm font-medium">Organic Wheat - 10 kg</p>
                <p class="text-xs text-gray-400">From: Ramesh Patil Farm</p>
              </div>
            </div>
            <div class="text-right">
              <p class="text-sm font-bold">&#8377;350</p>
              <span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Delivered</span>
            </div>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center"><i class="fas fa-apple-whole text-amber-600 text-sm"></i></div>
              <div>
                <p class="text-sm font-medium">Fresh Tomatoes - 5 kg</p>
                <p class="text-xs text-gray-400">From: Krishna Wholesale</p>
              </div>
            </div>
            <div class="text-right">
              <p class="text-sm font-bold">&#8377;200</p>
              <span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">In Transit</span>
            </div>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center"><i class="fas fa-carrot text-blue-600 text-sm"></i></div>
              <div>
                <p class="text-sm font-medium">Red Onions - 8 kg</p>
                <p class="text-xs text-gray-400">From: Sahyadri Traders</p>
              </div>
            </div>
            <div class="text-right">
              <p class="text-sm font-bold">&#8377;240</p>
              <span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Processing</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Access -->
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Quick Access</h3>
        <div class="space-y-3">
          <a href="/buyer/browse" class="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 transition">
            <div class="w-9 h-9 bg-blue-200 rounded-lg flex items-center justify-center"><i class="fas fa-search text-blue-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">Browse Products</p><p class="text-xs text-gray-400">Find fresh produce</p></div>
          </a>
          <a href="/buyer/cart" class="flex items-center gap-3 p-3 rounded-xl bg-amber-50 hover:bg-amber-100 transition">
            <div class="w-9 h-9 bg-amber-200 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-cart text-amber-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">My Cart</p><p class="text-xs text-gray-400">3 items</p></div>
          </a>
          <a href="/buyer/tracking" class="flex items-center gap-3 p-3 rounded-xl bg-green-50 hover:bg-green-100 transition">
            <div class="w-9 h-9 bg-green-200 rounded-lg flex items-center justify-center"><i class="fas fa-map-marked text-green-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">Track Orders</p><p class="text-xs text-gray-400">2 active deliveries</p></div>
          </a>
        </div>
      </div>
    </div>

    <!-- Recommended Products -->
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-800">Recommended For You</h3>
        <a href="/buyer/browse" class="text-sm text-blue-600 hover:underline font-medium">See All</a>
      </div>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        ${[
          { name: 'Organic Basmati Rice', price: 80, seller: 'Krishna Wholesale', unit: 'kg' },
          { name: 'Fresh Green Chillies', price: 60, seller: 'Ramesh Farm', unit: 'kg' },
          { name: 'Alphonso Mangoes', price: 400, seller: 'Meera Farms', unit: 'dozen' },
          { name: 'Farm Fresh Potatoes', price: 25, seller: 'Sunil Farms', unit: 'kg' },
        ].map(p => `
          <div class="border border-gray-100 rounded-xl overflow-hidden card-hover">
            <div class="h-24 bg-gradient-to-br from-blue-50 to-primary-50 flex items-center justify-center">
              <i class="fas fa-seedling text-primary-300 text-2xl"></i>
            </div>
            <div class="p-3">
              <h4 class="text-sm font-bold text-gray-800 mb-1 truncate">${p.name}</h4>
              <p class="text-xs text-gray-400 mb-2">${p.seller}</p>
              <div class="flex items-center justify-between">
                <span class="text-sm font-bold text-blue-600">&#8377;${p.price}/${p.unit}</span>
                <button class="text-xs bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded-lg transition">Add</button>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  </div>`;

  return dashboardLayout('Dashboard', 'buyer', body, 'dashboard');
}
