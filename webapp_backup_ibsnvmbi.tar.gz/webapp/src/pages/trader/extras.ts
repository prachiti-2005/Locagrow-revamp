import { dashboardLayout } from '../../layout';

export function traderFarmers(): string {
  const farmers = [
    { name: 'Ramesh Patil', loc: 'Nashik, MH', crops: ['Wheat','Rice','Tomatoes'], rating: 4.8, organic: true, initial: 'RP' },
    { name: 'Sunil Jadhav', loc: 'Pune, MH', crops: ['Onions','Potatoes'], rating: 4.5, organic: false, initial: 'SJ' },
    { name: 'Ganesh Bhosle', loc: 'Aurangabad, MH', crops: ['Cotton','Sugarcane'], rating: 4.7, organic: true, initial: 'GB' },
    { name: 'Priya Deshmukh', loc: 'Nagpur, MH', crops: ['Oranges','Grapes'], rating: 4.9, organic: true, initial: 'PD' },
    { name: 'Anil Kulkarni', loc: 'Kolhapur, MH', crops: ['Sugarcane','Jaggery'], rating: 4.3, organic: false, initial: 'AK' },
    { name: 'Meera Sawant', loc: 'Ratnagiri, MH', crops: ['Mangoes','Cashew'], rating: 4.6, organic: true, initial: 'MS' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="bg-white rounded-2xl p-4 border border-gray-100">
      <div class="flex flex-wrap gap-3">
        <div class="relative flex-1 min-w-[200px]">
          <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
          <input type="text" placeholder="Search farmers by name or crop..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-amber-500">
        </div>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>All Locations</option><option>Nashik</option><option>Pune</option><option>Aurangabad</option>
        </select>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>All Crops</option><option>Grains</option><option>Vegetables</option><option>Fruits</option>
        </select>
      </div>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
      ${farmers.map(f => `
        <div class="bg-white rounded-2xl border border-gray-100 p-5 card-hover">
          <div class="flex items-center gap-3 mb-4">
            <div class="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-amber-700 font-bold">${f.initial}</div>
            <div>
              <div class="flex items-center gap-2">
                <h4 class="font-bold text-gray-800">${f.name}</h4>
                ${f.organic ? '<span class="text-xs bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full">Organic</span>' : ''}
              </div>
              <p class="text-xs text-gray-400"><i class="fas fa-map-marker-alt mr-1"></i>${f.loc}</p>
            </div>
          </div>
          <div class="flex flex-wrap gap-1.5 mb-3">
            ${f.crops.map(c => '<span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">' + c + '</span>').join('')}
          </div>
          <div class="flex items-center justify-between">
            <span class="flex items-center gap-1 text-sm"><i class="fas fa-star text-yellow-400"></i>${f.rating}</span>
            <button class="bg-amber-500 hover:bg-amber-600 text-white text-xs px-4 py-1.5 rounded-lg font-medium transition">View Crops</button>
          </div>
        </div>
      `).join('')}
    </div>
  </div>`;

  return dashboardLayout('Nearby Farmers', 'trader', body, 'farmers');
}

export function traderMarketplace(): string {
  const items = [
    { name: 'Organic Wheat', farmer: 'Ramesh Patil', price: 25, qty: '5 tons available', loc: 'Nashik', organic: true },
    { name: 'Basmati Rice', farmer: 'Sunil Jadhav', price: 65, qty: '3 tons available', loc: 'Pune', organic: false },
    { name: 'Fresh Tomatoes', farmer: 'Ganesh Bhosle', price: 40, qty: '800 kg available', loc: 'Aurangabad', organic: true },
    { name: 'Red Onions', farmer: 'Priya Deshmukh', price: 30, qty: '2 tons available', loc: 'Nagpur', organic: false },
    { name: 'Cotton Bales', farmer: 'Anil Kulkarni', price: 6500, qty: '50 bales available', loc: 'Kolhapur', organic: false },
    { name: 'Alphonso Mangoes', farmer: 'Meera Sawant', price: 400, qty: '500 boxes available', loc: 'Ratnagiri', organic: true },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="bg-white rounded-2xl p-4 border border-gray-100">
      <div class="flex flex-wrap gap-3">
        <div class="relative flex-1 min-w-[200px]">
          <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
          <input type="text" placeholder="Search crops for bulk purchase..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-amber-500">
        </div>
        <select class="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 outline-none">
          <option>Sort by Price</option><option>Sort by Quantity</option><option>Sort by Distance</option>
        </select>
      </div>
    </div>

    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      ${items.map(item => `
        <div class="bg-white rounded-2xl border border-gray-100 overflow-hidden card-hover">
          <div class="h-28 bg-gradient-to-br from-amber-50 to-amber-100 flex items-center justify-center relative">
            <i class="fas fa-seedling text-amber-300 text-4xl"></i>
            ${item.organic ? '<span class="absolute top-3 right-3 text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">Organic</span>' : ''}
          </div>
          <div class="p-4">
            <h4 class="font-bold text-gray-800 mb-1">${item.name}</h4>
            <p class="text-xs text-gray-400 mb-2"><i class="fas fa-user mr-1"></i>${item.farmer} | <i class="fas fa-map-marker-alt mr-1"></i>${item.loc}</p>
            <p class="text-xs text-gray-500 mb-3">${item.qty}</p>
            <div class="flex items-center justify-between">
              <span class="font-bold text-amber-600">&#8377;${item.price.toLocaleString()}/kg</span>
              <button class="bg-amber-500 hover:bg-amber-600 text-white text-xs px-4 py-1.5 rounded-lg font-medium transition">Buy Bulk</button>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  </div>`;

  return dashboardLayout('Marketplace', 'trader', body, 'marketplace');
}

export function traderProducts(): string {
  const products = [
    { name: 'Premium Wheat Flour', price: 35, stock: 2000, sold: 450, status: 'active' },
    { name: 'Organic Basmati Rice', price: 80, stock: 1500, sold: 320, status: 'active' },
    { name: 'Fresh Tomato Puree', price: 60, stock: 500, sold: 180, status: 'active' },
    { name: 'Red Onion Pack (5kg)', price: 150, stock: 0, sold: 890, status: 'out-of-stock' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h3 class="text-lg font-bold text-gray-800">My Products</h3>
        <p class="text-sm text-gray-400">Products you sell to buyers</p>
      </div>
      <button onclick="document.getElementById('addProductModal').classList.remove('hidden')" class="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-xl text-sm font-medium transition inline-flex items-center gap-2">
        <i class="fas fa-plus"></i> Add Product
      </button>
    </div>

    <div class="grid sm:grid-cols-2 gap-4">
      ${products.map(p => `
        <div class="bg-white rounded-2xl border border-gray-100 p-5 card-hover">
          <div class="flex items-center justify-between mb-3">
            <h4 class="font-bold text-gray-800">${p.name}</h4>
            <span class="text-xs px-2 py-1 rounded-full font-medium ${p.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">${p.status === 'active' ? 'Active' : 'Out of Stock'}</span>
          </div>
          <div class="grid grid-cols-3 gap-3 mb-4">
            <div class="text-center p-2 bg-gray-50 rounded-lg">
              <p class="text-lg font-bold text-gray-800">&#8377;${p.price}</p>
              <p class="text-xs text-gray-400">Price/kg</p>
            </div>
            <div class="text-center p-2 bg-gray-50 rounded-lg">
              <p class="text-lg font-bold text-gray-800">${p.stock}</p>
              <p class="text-xs text-gray-400">In Stock</p>
            </div>
            <div class="text-center p-2 bg-gray-50 rounded-lg">
              <p class="text-lg font-bold text-green-600">${p.sold}</p>
              <p class="text-xs text-gray-400">Sold</p>
            </div>
          </div>
          <div class="flex gap-2">
            <button class="flex-1 text-xs bg-gray-50 hover:bg-gray-100 text-gray-700 py-2 rounded-lg font-medium transition"><i class="fas fa-edit mr-1"></i>Edit</button>
            <button class="text-xs bg-red-50 hover:bg-red-100 text-red-600 py-2 px-3 rounded-lg font-medium transition"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      `).join('')}
    </div>

    <!-- Add Product Modal -->
    <div id="addProductModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl w-full max-w-lg p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-bold text-gray-800">Add New Product</h3>
          <button onclick="document.getElementById('addProductModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <form onsubmit="event.preventDefault(); document.getElementById('addProductModal').classList.add('hidden'); showToast('Product added successfully!');" class="space-y-4">
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Product Name</label><input type="text" placeholder="e.g., Premium Wheat Flour" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-amber-500" required></div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Price per kg</label><input type="number" placeholder="0" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none" required></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Stock (kg)</label><input type="number" placeholder="0" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none" required></div>
          </div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Description</label><textarea rows="3" class="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none resize-none" placeholder="Product details..."></textarea></div>
          <div class="flex gap-3">
            <button type="button" onclick="document.getElementById('addProductModal').classList.add('hidden')" class="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">Cancel</button>
            <button type="submit" class="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-2.5 rounded-xl text-sm font-medium transition">Add Product</button>
          </div>
        </form>
      </div>
    </div>
  </div>`;

  return dashboardLayout('My Products', 'trader', body, 'products');
}

export function traderOrders(): string {
  const orders = [
    { id: '#TRD-5012', type: 'purchase', from: 'Ramesh Farm', item: 'Wheat - 2 tons', amount: '50,000', date: 'Mar 28', status: 'completed', color: 'green' },
    { id: '#TRD-5011', type: 'sale', from: 'Fresh Mart', item: 'Premium Wheat - 100 kg', amount: '3,500', date: 'Mar 27', status: 'in-transit', color: 'amber' },
    { id: '#TRD-5010', type: 'purchase', from: 'Sunil Farms', item: 'Tomatoes - 500 kg', amount: '20,000', date: 'Mar 26', status: 'processing', color: 'blue' },
    { id: '#TRD-5009', type: 'sale', from: 'Super Bazaar', item: 'Red Onions - 200 kg', amount: '6,000', date: 'Mar 25', status: 'completed', color: 'green' },
  ];

  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-800">All Orders</h3>
        <div class="flex gap-2">
          <button class="text-sm bg-amber-100 text-amber-700 px-3 py-1.5 rounded-lg font-medium">All</button>
          <button class="text-sm text-gray-500 px-3 py-1.5 rounded-lg hover:bg-gray-50">Purchases</button>
          <button class="text-sm text-gray-500 px-3 py-1.5 rounded-lg hover:bg-gray-50">Sales</button>
        </div>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead>
            <tr class="text-left text-gray-400 border-b border-gray-100">
              <th class="pb-3 font-medium">ID</th><th class="pb-3 font-medium">Type</th><th class="pb-3 font-medium">Party</th><th class="pb-3 font-medium">Item</th><th class="pb-3 font-medium">Amount</th><th class="pb-3 font-medium">Date</th><th class="pb-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-50">
            ${orders.map(o => `
              <tr class="hover:bg-gray-50 transition">
                <td class="py-3 font-medium">${o.id}</td>
                <td class="py-3"><span class="text-xs px-2 py-0.5 rounded-full ${o.type === 'purchase' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}">${o.type}</span></td>
                <td class="py-3 text-gray-600">${o.from}</td>
                <td class="py-3">${o.item}</td>
                <td class="py-3 font-medium">&#8377;${o.amount}</td>
                <td class="py-3 text-gray-400">${o.date}</td>
                <td class="py-3"><span class="bg-${o.color}-100 text-${o.color}-700 text-xs px-2.5 py-1 rounded-full font-medium">${o.status}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  </div>`;

  return dashboardLayout('Orders', 'trader', body, 'orders');
}

export function traderDelivery(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid sm:grid-cols-3 gap-4">
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-truck text-amber-600"></i></div>
        <p class="text-2xl font-bold">5</p><p class="text-xs text-gray-400">In Transit</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-check text-green-600"></i></div>
        <p class="text-2xl font-bold">128</p><p class="text-xs text-gray-400">Delivered</p>
      </div>
      <div class="bg-white rounded-2xl p-4 border border-gray-100 text-center">
        <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2"><i class="fas fa-box text-blue-600"></i></div>
        <p class="text-2xl font-bold">8</p><p class="text-xs text-gray-400">Pending Pickup</p>
      </div>
    </div>

    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <h3 class="font-bold text-gray-800 mb-4">Active Shipments</h3>
      <div class="space-y-4">
        <div class="border border-gray-100 rounded-xl p-4">
          <div class="flex items-center justify-between mb-3">
            <span class="font-bold text-gray-800">SHP-3021</span>
            <span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">In Transit</span>
          </div>
          <div class="flex items-center gap-4 mb-2">
            <span class="text-xs text-gray-500 w-28 text-right">Nashik Farm</span>
            <div class="flex-1"><div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:60%"></div></div></div>
            <span class="text-xs text-gray-500 w-28">Pune Market</span>
          </div>
          <p class="text-xs text-gray-400 text-center">Wheat - 2 tons | Driver: Vijay | ETA: 3 hrs</p>
        </div>
        <div class="border border-gray-100 rounded-xl p-4">
          <div class="flex items-center justify-between mb-3">
            <span class="font-bold text-gray-800">SHP-3020</span>
            <span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Picked Up</span>
          </div>
          <div class="flex items-center gap-4 mb-2">
            <span class="text-xs text-gray-500 w-28 text-right">Warehouse</span>
            <div class="flex-1"><div class="w-full bg-gray-100 rounded-full h-2"><div class="bg-blue-500 rounded-full h-2" style="width:20%"></div></div></div>
            <span class="text-xs text-gray-500 w-28">Mumbai</span>
          </div>
          <p class="text-xs text-gray-400 text-center">Tomatoes - 500 kg | Driver: Rakesh | ETA: 6 hrs</p>
        </div>
      </div>
    </div>
  </div>`;

  return dashboardLayout('Delivery', 'trader', body, 'delivery');
}

export function traderAnalytics(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl p-5 border border-gray-100">
        <p class="text-sm text-gray-400">Gross Revenue</p>
        <p class="text-2xl font-bold text-gray-800 mt-1">&#8377;24.5L</p>
        <p class="text-xs text-green-600 mt-1"><i class="fas fa-arrow-up mr-1"></i>+12% vs last month</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100">
        <p class="text-sm text-gray-400">Net Profit</p>
        <p class="text-2xl font-bold text-green-600 mt-1">&#8377;5.8L</p>
        <p class="text-xs text-green-600 mt-1"><i class="fas fa-arrow-up mr-1"></i>+8% vs last month</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100">
        <p class="text-sm text-gray-400">Profit Margin</p>
        <p class="text-2xl font-bold text-amber-600 mt-1">23.7%</p>
        <p class="text-xs text-red-500 mt-1"><i class="fas fa-arrow-down mr-1"></i>-2% vs last month</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100">
        <p class="text-sm text-gray-400">Active Deals</p>
        <p class="text-2xl font-bold text-gray-800 mt-1">18</p>
        <p class="text-xs text-gray-400 mt-1">This month</p>
      </div>
    </div>

    <div class="grid lg:grid-cols-2 gap-6">
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Profit Trend</h3>
        <canvas id="profitChart" height="220"></canvas>
      </div>
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Category Breakdown</h3>
        <canvas id="categoryChart" height="220"></canvas>
      </div>
    </div>

    <div class="bg-white rounded-2xl p-6 border border-gray-100">
      <h3 class="font-bold text-gray-800 mb-4">Top Selling Products</h3>
      <div class="space-y-3">
        <div class="flex items-center justify-between"><span class="text-sm text-gray-600">Premium Wheat</span><div class="flex-1 mx-4"><div class="bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:90%"></div></div></div><span class="text-sm font-medium">&#8377;4.2L</span></div>
        <div class="flex items-center justify-between"><span class="text-sm text-gray-600">Organic Rice</span><div class="flex-1 mx-4"><div class="bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:75%"></div></div></div><span class="text-sm font-medium">&#8377;3.5L</span></div>
        <div class="flex items-center justify-between"><span class="text-sm text-gray-600">Red Onions</span><div class="flex-1 mx-4"><div class="bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:60%"></div></div></div><span class="text-sm font-medium">&#8377;2.8L</span></div>
        <div class="flex items-center justify-between"><span class="text-sm text-gray-600">Tomato Puree</span><div class="flex-1 mx-4"><div class="bg-gray-100 rounded-full h-2"><div class="bg-amber-500 rounded-full h-2" style="width:45%"></div></div></div><span class="text-sm font-medium">&#8377;2.1L</span></div>
      </div>
    </div>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    var profitCtx = document.getElementById('profitChart');
    if (profitCtx) {
      new Chart(profitCtx, {
        type: 'line',
        data: {
          labels: ['Oct','Nov','Dec','Jan','Feb','Mar'],
          datasets: [
            { label: 'Revenue', data: [180000,210000,195000,230000,220000,245000], borderColor: '#f59e0b', backgroundColor: 'rgba(245,158,11,0.1)', fill: true, tension: 0.4 },
            { label: 'Profit', data: [42000,51000,45000,55000,52000,58000], borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.1)', fill: true, tension: 0.4 }
          ]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true } } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
      });
    }
    var catCtx = document.getElementById('categoryChart');
    if (catCtx) {
      new Chart(catCtx, {
        type: 'doughnut',
        data: {
          labels: ['Grains','Vegetables','Fruits','Spices'],
          datasets: [{ data: [45,25,20,10], backgroundColor: ['#f59e0b','#22c55e','#3b82f6','#a855f7'], borderWidth: 0 }]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 15 } } }, cutout: '65%' }
      });
    }
  });
  </script>`;

  return dashboardLayout('Analytics', 'trader', body, 'analytics');
}
