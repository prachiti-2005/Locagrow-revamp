import { dashboardLayout } from '../../layout';

export function traderDashboard(): string {
  const body = `
  <div class="space-y-6 animate-fade-in">
    <!-- Stats -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center"><i class="fas fa-store text-amber-600"></i></div>
          <span class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full font-medium">+5%</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">42</p>
        <p class="text-sm text-gray-400">Active Listings</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center"><i class="fas fa-clipboard-list text-blue-600"></i></div>
          <span class="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-full font-medium">12 new</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">34</p>
        <p class="text-sm text-gray-400">Pending Orders</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center"><i class="fas fa-rupee-sign text-green-600"></i></div>
          <span class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full font-medium">+15%</span>
        </div>
        <p class="text-2xl font-bold text-gray-800">&#8377;8.6L</p>
        <p class="text-sm text-gray-400">Monthly Revenue</p>
      </div>
      <div class="bg-white rounded-2xl p-5 border border-gray-100 card-hover">
        <div class="flex items-center justify-between mb-3">
          <div class="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center"><i class="fas fa-users text-purple-600"></i></div>
        </div>
        <p class="text-2xl font-bold text-gray-800">15</p>
        <p class="text-sm text-gray-400">Farmer Partners</p>
      </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">
      <!-- Revenue Chart -->
      <div class="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-6">
          <h3 class="font-bold text-gray-800">Revenue Overview</h3>
          <select class="text-sm border border-gray-200 rounded-lg px-3 py-1.5 text-gray-600 outline-none">
            <option>This Month</option><option>Last 3 Months</option><option>This Year</option>
          </select>
        </div>
        <canvas id="revenueChart" height="200"></canvas>
      </div>

      <!-- Quick Actions -->
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-3">
          <a href="/trader/farmers" class="flex items-center gap-3 p-3 rounded-xl bg-primary-50 hover:bg-primary-100 transition group">
            <div class="w-9 h-9 bg-primary-200 rounded-lg flex items-center justify-center"><i class="fas fa-search text-primary-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">Find Farmers</p><p class="text-xs text-gray-400">Browse nearby farmers</p></div>
          </a>
          <a href="/trader/marketplace" class="flex items-center gap-3 p-3 rounded-xl bg-amber-50 hover:bg-amber-100 transition group">
            <div class="w-9 h-9 bg-amber-200 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-basket text-amber-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">Buy Crops</p><p class="text-xs text-gray-400">Bulk purchase</p></div>
          </a>
          <a href="/trader/products" class="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 transition group">
            <div class="w-9 h-9 bg-blue-200 rounded-lg flex items-center justify-center"><i class="fas fa-plus text-blue-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">List Product</p><p class="text-xs text-gray-400">Add to marketplace</p></div>
          </a>
          <a href="/trader/analytics" class="flex items-center gap-3 p-3 rounded-xl bg-purple-50 hover:bg-purple-100 transition group">
            <div class="w-9 h-9 bg-purple-200 rounded-lg flex items-center justify-center"><i class="fas fa-chart-pie text-purple-700 text-sm"></i></div>
            <div><p class="text-sm font-medium text-gray-800">Analytics</p><p class="text-xs text-gray-400">Profit insights</p></div>
          </a>
        </div>
      </div>
    </div>

    <!-- Recent Purchases & Sales -->
    <div class="grid md:grid-cols-2 gap-6">
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Recent Purchases from Farmers</h3>
        <div class="space-y-3">
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-primary-100 rounded-lg flex items-center justify-center"><i class="fas fa-seedling text-primary-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Wheat - 2 tons</p><p class="text-xs text-gray-400">From: Ramesh Farm</p></div>
            </div>
            <span class="text-sm font-bold">&#8377;50,000</span>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-amber-100 rounded-lg flex items-center justify-center"><i class="fas fa-apple-whole text-amber-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Tomatoes - 500 kg</p><p class="text-xs text-gray-400">From: Sunil Farms</p></div>
            </div>
            <span class="text-sm font-bold">&#8377;20,000</span>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center"><i class="fas fa-carrot text-blue-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Onions - 1 ton</p><p class="text-xs text-gray-400">From: Ganesh Farm</p></div>
            </div>
            <span class="text-sm font-bold">&#8377;30,000</span>
          </div>
        </div>
      </div>
      <div class="bg-white rounded-2xl p-6 border border-gray-100">
        <h3 class="font-bold text-gray-800 mb-4">Recent Sales to Buyers</h3>
        <div class="space-y-3">
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-bag text-green-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Premium Wheat - 100 kg</p><p class="text-xs text-gray-400">To: Fresh Mart Store</p></div>
            </div>
            <span class="text-sm font-bold text-green-600">&#8377;3,500</span>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-bag text-green-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Organic Tomatoes - 50 kg</p><p class="text-xs text-gray-400">To: City Grocers</p></div>
            </div>
            <span class="text-sm font-bold text-green-600">&#8377;2,500</span>
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-bag text-green-600 text-sm"></i></div>
              <div><p class="text-sm font-medium">Red Onions - 200 kg</p><p class="text-xs text-gray-400">To: Super Bazaar</p></div>
            </div>
            <span class="text-sm font-bold text-green-600">&#8377;6,000</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById('revenueChart');
    if (ctx) {
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Week 1','Week 2','Week 3','Week 4'],
          datasets: [
            { label: 'Purchases', data: [120000,95000,150000,110000], backgroundColor: 'rgba(245,158,11,0.7)', borderRadius: 8 },
            { label: 'Sales', data: [180000,145000,210000,175000], backgroundColor: 'rgba(34,197,94,0.7)', borderRadius: 8 }
          ]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true } } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
      });
    }
  });
  </script>`;

  return dashboardLayout('Dashboard', 'trader', body, 'dashboard');
}
