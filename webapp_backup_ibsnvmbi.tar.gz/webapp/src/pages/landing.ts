import { baseLayout } from '../layout';

export function landingPage(): string {
  const body = `
  <!-- Navbar -->
  <nav class="fixed top-0 left-0 right-0 z-50 glass border-b border-gray-200/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16">
        <div class="flex items-center gap-2">
          <div class="w-9 h-9 bg-primary-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-leaf text-primary-600"></i>
          </div>
          <span class="text-xl font-bold text-gray-800">AgriMarket</span>
        </div>
        <div class="hidden md:flex items-center gap-6">
          <a href="#features" class="text-gray-600 hover:text-primary-600 text-sm font-medium transition">Features</a>
          <a href="#roles" class="text-gray-600 hover:text-primary-600 text-sm font-medium transition">For You</a>
          <a href="#how" class="text-gray-600 hover:text-primary-600 text-sm font-medium transition">How It Works</a>
          <a href="/login" class="text-primary-600 font-medium text-sm">Login</a>
          <a href="/signup" class="btn-primary text-white px-5 py-2 rounded-xl text-sm font-medium">Get Started</a>
        </div>
        <button onclick="toggleMobileMenu()" class="md:hidden text-gray-600"><i class="fas fa-bars text-xl"></i></button>
      </div>
    </div>
    <div id="mobileMenu" class="mobile-menu md:hidden bg-white border-t">
      <a href="#features" class="block px-4 py-3 text-gray-600">Features</a>
      <a href="#roles" class="block px-4 py-3 text-gray-600">For You</a>
      <a href="/login" class="block px-4 py-3 text-primary-600 font-medium">Login</a>
      <a href="/signup" class="block px-4 py-3 bg-primary-50 text-primary-700 font-medium">Get Started</a>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="gradient-bg pt-28 pb-20 px-4">
    <div class="max-w-7xl mx-auto">
      <div class="grid md:grid-cols-2 gap-12 items-center">
        <div class="animate-fade-in">
          <div class="inline-flex items-center gap-2 bg-white/80 px-4 py-2 rounded-full text-sm text-primary-700 font-medium mb-6 shadow-sm">
            <i class="fas fa-sparkles text-yellow-500"></i>
            Smart Agriculture Marketplace
          </div>
          <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
            Grow <span class="text-primary-600">Smarter</span>,<br>Trade <span class="text-primary-600">Better</span>
          </h1>
          <p class="text-lg text-gray-600 mb-8 max-w-lg">
            Connect farmers, traders, and buyers on one intelligent platform. AI-powered soil analysis, real-time market trends, and seamless trading.
          </p>
          <div class="flex flex-wrap gap-4">
            <a href="/signup" class="btn-primary text-white px-8 py-3 rounded-xl font-medium text-lg inline-flex items-center gap-2">
              <i class="fas fa-rocket"></i> Start Free
            </a>
            <a href="#how" class="bg-white text-gray-700 px-8 py-3 rounded-xl font-medium text-lg inline-flex items-center gap-2 shadow-sm hover:shadow-md transition">
              <i class="fas fa-play-circle text-primary-500"></i> Learn More
            </a>
          </div>
          <div class="flex items-center gap-8 mt-10 text-sm text-gray-500">
            <div class="flex items-center gap-2"><i class="fas fa-users text-primary-500"></i> 10K+ Farmers</div>
            <div class="flex items-center gap-2"><i class="fas fa-store text-primary-500"></i> 2K+ Traders</div>
            <div class="flex items-center gap-2"><i class="fas fa-star text-yellow-500"></i> 4.8 Rating</div>
          </div>
        </div>
        <div class="animate-fade-in hidden md:block">
          <div class="relative">
            <div class="bg-white rounded-3xl shadow-xl p-8 transform rotate-2 hover:rotate-0 transition-transform duration-500">
              <div class="grid grid-cols-2 gap-4">
                <div class="bg-primary-50 rounded-2xl p-4 text-center">
                  <i class="fas fa-seedling text-primary-500 text-3xl mb-2"></i>
                  <p class="text-sm font-medium text-gray-700">Fresh Crops</p>
                  <p class="text-xs text-gray-400">Direct from farm</p>
                </div>
                <div class="bg-amber-50 rounded-2xl p-4 text-center">
                  <i class="fas fa-chart-line text-amber-500 text-3xl mb-2"></i>
                  <p class="text-sm font-medium text-gray-700">Market Trends</p>
                  <p class="text-xs text-gray-400">Real-time data</p>
                </div>
                <div class="bg-blue-50 rounded-2xl p-4 text-center">
                  <i class="fas fa-flask text-blue-500 text-3xl mb-2"></i>
                  <p class="text-sm font-medium text-gray-700">Soil Analysis</p>
                  <p class="text-xs text-gray-400">AI powered</p>
                </div>
                <div class="bg-purple-50 rounded-2xl p-4 text-center">
                  <i class="fas fa-truck text-purple-500 text-3xl mb-2"></i>
                  <p class="text-sm font-medium text-gray-700">Fast Delivery</p>
                  <p class="text-xs text-gray-400">Pan India</p>
                </div>
              </div>
            </div>
            <div class="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg p-4 animate-fade-in" style="animation-delay:0.3s">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <i class="fas fa-check text-green-600"></i>
                </div>
                <div>
                  <p class="text-sm font-medium text-gray-800">Order Completed</p>
                  <p class="text-xs text-gray-400">2 min ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Features -->
  <section id="features" class="py-20 px-4 bg-white">
    <div class="max-w-7xl mx-auto">
      <div class="text-center mb-16">
        <span class="text-primary-600 font-medium text-sm uppercase tracking-wider">Features</span>
        <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">Everything You Need</h2>
        <p class="text-gray-500 max-w-2xl mx-auto">A complete ecosystem for modern agriculture — from soil to sale.</p>
      </div>
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        ${[
          { icon: 'fa-brain', color: 'primary', title: 'AI Soil Analysis', desc: 'Get instant soil health reports with fertilizer & pesticide recommendations.' },
          { icon: 'fa-chart-bar', color: 'amber', title: 'Market Trends', desc: 'Real-time crop pricing and demand analytics across regions.' },
          { icon: 'fa-flask', color: 'blue', title: 'Lab Finder & Booking', desc: 'Locate nearby soil testing labs and book appointments online.' },
          { icon: 'fa-handshake', color: 'purple', title: 'Trader Discovery', desc: 'Connect with verified traders for bulk purchasing opportunities.' },
          { icon: 'fa-shopping-cart', color: 'rose', title: 'Seamless Commerce', desc: 'List products, manage cart, checkout, and track orders easily.' },
          { icon: 'fa-truck', color: 'teal', title: 'Delivery Management', desc: 'End-to-end delivery logistics with real-time tracking.' }
        ].map(f => `
          <div class="card-hover bg-white border border-gray-100 rounded-2xl p-6 group">
            <div class="w-12 h-12 bg-${f.color}-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <i class="fas ${f.icon} text-${f.color}-600 text-xl"></i>
            </div>
            <h3 class="font-bold text-gray-800 mb-2">${f.title}</h3>
            <p class="text-sm text-gray-500">${f.desc}</p>
          </div>
        `).join('')}
      </div>
    </div>
  </section>

  <!-- Roles -->
  <section id="roles" class="py-20 px-4 bg-gray-50">
    <div class="max-w-7xl mx-auto">
      <div class="text-center mb-16">
        <span class="text-primary-600 font-medium text-sm uppercase tracking-wider">For Everyone</span>
        <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">Choose Your Role</h2>
        <p class="text-gray-500 max-w-2xl mx-auto">Whether you grow, trade, or buy — we have the tools for you.</p>
      </div>
      <div class="grid md:grid-cols-3 gap-8">
        <div class="card-hover bg-white rounded-2xl p-8 border border-gray-100 text-center">
          <div class="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-seedling text-primary-600 text-3xl"></i>
          </div>
          <h3 class="text-xl font-bold text-gray-800 mb-3">Farmer</h3>
          <p class="text-gray-500 text-sm mb-6">List crops, test soil, get AI recommendations, find traders, and manage deliveries.</p>
          <ul class="text-left text-sm space-y-2 mb-6">
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-primary-500 text-xs"></i> Crop Listing & Pricing</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-primary-500 text-xs"></i> AI Soil Analysis</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-primary-500 text-xs"></i> Lab Booking</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-primary-500 text-xs"></i> Trader Discovery</li>
          </ul>
          <a href="/farmer/dashboard" class="btn-primary text-white px-6 py-2.5 rounded-xl text-sm font-medium inline-block w-full">Enter as Farmer</a>
        </div>
        <div class="card-hover bg-white rounded-2xl p-8 border border-gray-100 text-center relative overflow-hidden">
          <div class="absolute top-4 right-4 bg-amber-100 text-amber-700 text-xs font-medium px-3 py-1 rounded-full">Popular</div>
          <div class="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-handshake text-amber-600 text-3xl"></i>
          </div>
          <h3 class="text-xl font-bold text-gray-800 mb-3">Trader</h3>
          <p class="text-gray-500 text-sm mb-6">Bulk purchase from farmers, list products for buyers, and track profit analytics.</p>
          <ul class="text-left text-sm space-y-2 mb-6">
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-amber-500 text-xs"></i> Bulk Purchasing</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-amber-500 text-xs"></i> Product Listing</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-amber-500 text-xs"></i> Order Management</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-amber-500 text-xs"></i> Profit Analytics</li>
          </ul>
          <a href="/trader/dashboard" class="bg-amber-500 hover:bg-amber-600 text-white px-6 py-2.5 rounded-xl text-sm font-medium inline-block w-full transition">Enter as Trader</a>
        </div>
        <div class="card-hover bg-white rounded-2xl p-8 border border-gray-100 text-center">
          <div class="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-shopping-bag text-blue-600 text-3xl"></i>
          </div>
          <h3 class="text-xl font-bold text-gray-800 mb-3">Buyer</h3>
          <p class="text-gray-500 text-sm mb-6">Browse fresh produce, add to cart, checkout securely, and track deliveries.</p>
          <ul class="text-left text-sm space-y-2 mb-6">
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-blue-500 text-xs"></i> Product Search</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-blue-500 text-xs"></i> Cart & Checkout</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-blue-500 text-xs"></i> Order Tracking</li>
            <li class="flex items-center gap-2 text-gray-600"><i class="fas fa-check-circle text-blue-500 text-xs"></i> Farmer Direct</li>
          </ul>
          <a href="/buyer/dashboard" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-medium inline-block w-full transition">Enter as Buyer</a>
        </div>
      </div>
    </div>
  </section>

  <!-- How It Works -->
  <section id="how" class="py-20 px-4 bg-white">
    <div class="max-w-7xl mx-auto">
      <div class="text-center mb-16">
        <span class="text-primary-600 font-medium text-sm uppercase tracking-wider">Simple Process</span>
        <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">How It Works</h2>
      </div>
      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        ${[
          { step: '01', icon: 'fa-user-plus', title: 'Sign Up', desc: 'Create your account and choose your role.' },
          { step: '02', icon: 'fa-cogs', title: 'Set Up Profile', desc: 'Add your farm, business, or preferences.' },
          { step: '03', icon: 'fa-exchange-alt', title: 'Connect & Trade', desc: 'List products or browse marketplace.' },
          { step: '04', icon: 'fa-smile', title: 'Grow Together', desc: 'Track orders and grow your business.' }
        ].map(s => `
          <div class="text-center group">
            <div class="relative inline-block mb-6">
              <div class="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center group-hover:bg-primary-200 transition">
                <i class="fas ${s.icon} text-primary-600 text-2xl"></i>
              </div>
              <span class="absolute -top-2 -right-2 w-7 h-7 bg-primary-600 text-white text-xs font-bold rounded-full flex items-center justify-center">${s.step}</span>
            </div>
            <h3 class="font-bold text-gray-800 mb-2">${s.title}</h3>
            <p class="text-sm text-gray-500">${s.desc}</p>
          </div>
        `).join('')}
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-900 text-gray-400 py-12 px-4">
    <div class="max-w-7xl mx-auto">
      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
        <div>
          <div class="flex items-center gap-2 mb-4">
            <i class="fas fa-leaf text-primary-400 text-xl"></i>
            <span class="text-white font-bold text-lg">AgriMarket</span>
          </div>
          <p class="text-sm">Empowering agriculture with technology. Connecting farms to markets seamlessly.</p>
        </div>
        <div>
          <h4 class="text-white font-medium mb-4">Platform</h4>
          <div class="space-y-2 text-sm">
            <a href="/farmer/dashboard" class="block hover:text-primary-400 transition">For Farmers</a>
            <a href="/trader/dashboard" class="block hover:text-primary-400 transition">For Traders</a>
            <a href="/buyer/dashboard" class="block hover:text-primary-400 transition">For Buyers</a>
          </div>
        </div>
        <div>
          <h4 class="text-white font-medium mb-4">Features</h4>
          <div class="space-y-2 text-sm">
            <a href="/farmer/soil-test" class="block hover:text-primary-400 transition">Soil Analysis</a>
            <a href="/farmer/lab-finder" class="block hover:text-primary-400 transition">Lab Finder</a>
            <a href="/buyer/browse" class="block hover:text-primary-400 transition">Marketplace</a>
          </div>
        </div>
        <div>
          <h4 class="text-white font-medium mb-4">Contact</h4>
          <div class="space-y-2 text-sm">
            <p><i class="fas fa-envelope mr-2"></i>support@agrimarket.com</p>
            <p><i class="fas fa-phone mr-2"></i>+91 98765 43210</p>
          </div>
        </div>
      </div>
      <div class="border-t border-gray-800 pt-8 text-center text-sm">
        <p>&copy; 2026 AgriMarket. All rights reserved.</p>
      </div>
    </div>
  </footer>`;

  return baseLayout('Home', body);
}

export function loginPage(): string {
  const body = `
  <div class="min-h-screen gradient-bg flex items-center justify-center px-4 py-12">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <a href="/" class="inline-flex items-center gap-2 mb-6">
          <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-leaf text-primary-600 text-lg"></i>
          </div>
          <span class="text-2xl font-bold text-gray-800">AgriMarket</span>
        </a>
        <h2 class="text-2xl font-bold text-gray-900">Welcome Back</h2>
        <p class="text-gray-500 mt-1">Log in to your account</p>
      </div>
      <div class="bg-white rounded-2xl shadow-lg p-8">
        <form id="loginForm" onsubmit="handleLogin(event)">
          <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
            <div class="relative">
              <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="email" placeholder="you@example.com" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <div class="relative">
              <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="password" placeholder="Enter your password" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-2">Login as</label>
            <div class="grid grid-cols-3 gap-3">
              <label class="cursor-pointer">
                <input type="radio" name="role" value="farmer" class="hidden peer" checked>
                <div class="peer-checked:border-primary-500 peer-checked:bg-primary-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-seedling text-primary-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Farmer</p>
                </div>
              </label>
              <label class="cursor-pointer">
                <input type="radio" name="role" value="trader" class="hidden peer">
                <div class="peer-checked:border-amber-500 peer-checked:bg-amber-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-handshake text-amber-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Trader</p>
                </div>
              </label>
              <label class="cursor-pointer">
                <input type="radio" name="role" value="buyer" class="hidden peer">
                <div class="peer-checked:border-blue-500 peer-checked:bg-blue-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-shopping-bag text-blue-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Buyer</p>
                </div>
              </label>
            </div>
          </div>
          <button type="submit" class="btn-primary w-full text-white py-3 rounded-xl font-medium text-sm">
            <i class="fas fa-sign-in-alt mr-2"></i>Log In
          </button>
        </form>
        <p class="text-center text-sm text-gray-500 mt-6">
          Don't have an account? <a href="/signup" class="text-primary-600 font-medium hover:underline">Sign Up</a>
        </p>
      </div>
    </div>
  </div>`;
  return baseLayout('Login', body);
}

export function signupPage(): string {
  const body = `
  <div class="min-h-screen gradient-bg flex items-center justify-center px-4 py-12">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <a href="/" class="inline-flex items-center gap-2 mb-6">
          <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
            <i class="fas fa-leaf text-primary-600 text-lg"></i>
          </div>
          <span class="text-2xl font-bold text-gray-800">AgriMarket</span>
        </a>
        <h2 class="text-2xl font-bold text-gray-900">Create Account</h2>
        <p class="text-gray-500 mt-1">Join the agricultural revolution</p>
      </div>
      <div class="bg-white rounded-2xl shadow-lg p-8">
        <form id="signupForm" onsubmit="handleSignup(event)">
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
            <div class="relative">
              <i class="fas fa-user absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="text" placeholder="Your full name" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
            <div class="relative">
              <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="email" placeholder="you@example.com" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
            <div class="relative">
              <i class="fas fa-phone absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="tel" placeholder="+91 98765 43210" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <div class="relative">
              <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input type="password" placeholder="Create a strong password" class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition" required>
            </div>
          </div>
          <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-2">I am a</label>
            <div class="grid grid-cols-3 gap-3">
              <label class="cursor-pointer">
                <input type="radio" name="role" value="farmer" class="hidden peer" checked>
                <div class="peer-checked:border-primary-500 peer-checked:bg-primary-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-seedling text-primary-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Farmer</p>
                </div>
              </label>
              <label class="cursor-pointer">
                <input type="radio" name="role" value="trader" class="hidden peer">
                <div class="peer-checked:border-amber-500 peer-checked:bg-amber-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-handshake text-amber-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Trader</p>
                </div>
              </label>
              <label class="cursor-pointer">
                <input type="radio" name="role" value="buyer" class="hidden peer">
                <div class="peer-checked:border-blue-500 peer-checked:bg-blue-50 border-2 border-gray-200 rounded-xl p-3 text-center transition">
                  <i class="fas fa-shopping-bag text-blue-600 text-lg mb-1"></i>
                  <p class="text-xs font-medium">Buyer</p>
                </div>
              </label>
            </div>
          </div>
          <button type="submit" class="btn-primary w-full text-white py-3 rounded-xl font-medium text-sm">
            <i class="fas fa-user-plus mr-2"></i>Create Account
          </button>
        </form>
        <p class="text-center text-sm text-gray-500 mt-6">
          Already have an account? <a href="/login" class="text-primary-600 font-medium hover:underline">Log In</a>
        </p>
      </div>
    </div>
  </div>`;
  return baseLayout('Sign Up', body);
}
