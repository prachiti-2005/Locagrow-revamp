# AgriMarket - Agricultural Marketplace

## Project Overview
- **Name**: AgriMarket
- **Goal**: Complete agricultural marketplace connecting farmers, traders, and buyers
- **Tech Stack**: Hono + TypeScript + TailwindCSS (CDN) + Chart.js + Cloudflare Pages

## Features

### Completed Features
- **Landing Page**: Hero section, features grid, role selection cards, how it works, footer
- **Authentication**: Login & Sign Up pages with role-based selection (Farmer/Trader/Buyer)
- **Farmer Dashboard**: Stats, market price trends chart, quick actions, recent orders, soil health radar chart, crop performance
- **Farmer - My Crops**: Crop listing grid, add new crop modal, search/filter, edit/delete
- **Farmer - Soil Testing**: AI-powered soil analysis with upload, nutrient level results, recommendations, previous reports
- **Farmer - Lab Finder**: Nearby labs list with search/filter, booking modal, lab details
- **Farmer - AI Suggestions**: Pesticide & fertilizer recommendations, diagnosis, dosage tables
- **Farmer - Find Traders**: Trader discovery with ratings, specialities, contact
- **Farmer - Orders & Earnings**: Order history table with status tracking, revenue stats
- **Farmer - Delivery Management**: Active deliveries with progress tracking, driver details
- **Trader Dashboard**: Revenue chart, quick actions, recent purchases/sales
- **Trader - Nearby Farmers**: Farmer cards with crops, ratings, organic badges
- **Trader - Marketplace**: Bulk purchase listings from farmers
- **Trader - My Products**: Product management with stock tracking, add modal
- **Trader - Orders**: Combined purchase/sale order table
- **Trader - Delivery**: Shipment tracking with progress bars
- **Trader - Analytics**: Profit trends, category breakdown doughnut chart, top products
- **Buyer Dashboard**: Order stats, recent orders, quick access, recommended products
- **Buyer - Browse Products**: Product grid with search, filters, categories, organic badges
- **Buyer - Cart**: Cart items with quantity controls, order summary, coupon
- **Buyer - Checkout**: Address form, payment methods (UPI/Card/COD), order summary
- **Buyer - Orders**: Order history with status badges, track button
- **Buyer - Order Tracking**: Timeline progress, delivery partner details, delivery address

### Design Features
- Clean white theme with soft green/earthy accents
- Rounded cards, icons, micro-animations
- Fully mobile-responsive with sidebar navigation
- Charts (line, bar, radar, doughnut) via Chart.js
- Toast notifications, modals, smooth scrolling
- Role-based sidebar navigation

## URLs / Routes

### Public Pages
| Route | Description |
|-------|-------------|
| `/` | Landing page |
| `/login` | Login page with role selection |
| `/signup` | Sign up page with role selection |

### Farmer Routes
| Route | Description |
|-------|-------------|
| `/farmer/dashboard` | Farmer dashboard with stats & charts |
| `/farmer/crops` | Crop listing management |
| `/farmer/soil-test` | AI soil analysis |
| `/farmer/lab-finder` | Nearby lab finder & booking |
| `/farmer/pesticide` | AI pesticide/fertilizer suggestions |
| `/farmer/traders` | Find nearby traders |
| `/farmer/orders` | Orders & earnings |
| `/farmer/delivery` | Delivery management |

### Trader Routes
| Route | Description |
|-------|-------------|
| `/trader/dashboard` | Trader dashboard |
| `/trader/farmers` | Browse nearby farmers |
| `/trader/marketplace` | Bulk purchase marketplace |
| `/trader/products` | My product listings |
| `/trader/orders` | Order management |
| `/trader/delivery` | Delivery logistics |
| `/trader/analytics` | Profit analytics |

### Buyer Routes
| Route | Description |
|-------|-------------|
| `/buyer/dashboard` | Buyer dashboard |
| `/buyer/browse` | Browse products |
| `/buyer/cart` | Shopping cart |
| `/buyer/checkout` | Checkout page |
| `/buyer/orders` | Order history |
| `/buyer/tracking` | Order tracking |

### API Endpoints
| Route | Description |
|-------|-------------|
| `/api/health` | Health check |
| `/api/products` | Product catalog |
| `/api/market-prices` | Market price data |

## Deployment
- **Platform**: Cloudflare Pages
- **Status**: Development (local sandbox)
- **Last Updated**: 2026-03-30
