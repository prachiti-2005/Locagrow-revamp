// AgriMarket - Main JavaScript
(function() {
  'use strict';

  // Mobile menu toggle
  window.toggleMobileMenu = function() {
    var menu = document.getElementById('mobileMenu');
    if (menu) {
      menu.classList.toggle('open');
    }
  };

  // Toast notification
  window.showToast = function(message, type) {
    type = type || 'success';
    var toast = document.createElement('div');
    var bgColor = type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-blue-500';
    toast.className = 'fixed bottom-4 right-4 z-50 ' + bgColor + ' text-white px-6 py-3 rounded-xl shadow-lg animate-fade-in flex items-center gap-2 text-sm';
    var icon = type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle';
    toast.innerHTML = '<i class="fas ' + icon + '"></i> ' + message;
    document.body.appendChild(toast);
    setTimeout(function() {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(function() { toast.remove(); }, 300);
    }, 3000);
  };

  // Login handler
  window.handleLogin = function(e) {
    e.preventDefault();
    var role = document.querySelector('input[name="role"]:checked');
    if (role) {
      window.location.href = '/' + role.value + '/dashboard';
    }
  };

  // Signup handler
  window.handleSignup = function(e) {
    e.preventDefault();
    var role = document.querySelector('input[name="role"]:checked');
    if (role) {
      showToast('Account created successfully!');
      setTimeout(function() {
        window.location.href = '/' + role.value + '/dashboard';
      }, 1000);
    }
  };

  // Add crop handler
  window.handleAddCrop = function(e) {
    e.preventDefault();
    var modal = document.getElementById('addCropModal');
    if (modal) modal.classList.add('hidden');
    showToast('Crop added successfully!');
  };

  // Edit/Delete crop
  window.editCrop = function(id) {
    showToast('Edit crop #' + id + ' - Opening editor...', 'info');
  };

  window.deleteCrop = function(id) {
    if (confirm('Are you sure you want to delete this crop?')) {
      showToast('Crop deleted successfully!');
    }
  };

  // Add to cart
  window.addToCart = function(id) {
    showToast('Added to cart!');
  };

  // Smooth scroll for anchor links
  document.addEventListener('click', function(e) {
    var target = e.target;
    if (target.tagName === 'A' && target.getAttribute('href') && target.getAttribute('href').startsWith('#')) {
      e.preventDefault();
      var el = document.querySelector(target.getAttribute('href'));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Close mobile menu if open
        var menu = document.getElementById('mobileMenu');
        if (menu) menu.classList.remove('open');
      }
    }
  });

  // Animate elements on scroll
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.card-hover').forEach(function(el) {
      observer.observe(el);
    });
  });
})();
